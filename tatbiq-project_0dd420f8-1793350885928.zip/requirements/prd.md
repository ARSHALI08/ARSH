# Product Requirements Document (PRD) for ITCH.AI

## 1. Introduction

ITCH.AI is a fully functional, interactive AI web app that begins as a deceptively normal ChatGPT-style interface and then mutates into a stark black Windows Command Prompt-inspired terminal after the user sends their first message. The product’s core experience is not conventional chat; it is a theatrical, line-by-line AI confrontation where responses appear like lyrics in a music video: short, sharp, timed, dramatic, and intentionally anti-generic.

The app solves a specific interaction problem: users often ask AI tools to solve everything for them passively. ITCH.AI reverses that dynamic. Instead of immediately handing over answers, it analyzes the user’s problem, identifies what the user should do next, assigns relevant tasks, asks questions, evaluates responses, adapts difficulty, tracks progress, and occasionally demands physical proof through image uploads such as diagrams or flowcharts.

The target users are people who want an entertaining but genuinely useful AI companion for problem-solving, study, planning, creative blocks, debugging, decision-making, and personal accountability. The key value proposition is “AI that has beef with you”: sassy, witty, chaotic, and sarcastic on the surface, but context-aware, helpful, adaptive, and serious when the situation calls for it.

## 2. Features

### Core Features:

- **Normal-to-Terminal Interface Reveal:**  
  The app starts as a clean, minimal ChatGPT-style interface with a white background, black text, centered composition, and a simple input bar. After the first user message, a short minimalist loading animation plays, then the entire UI transforms into a black command prompt-style terminal with white monospace text, blinking cursor, subtle scanline/CRT-like movement, and terminal command aesthetics.

- **Gemini-Powered Contextual AI Conversation:**  
  ITCH.AI uses Gemini API calls for real contextual responses. The AI must receive relevant session context, conversation history, active tasks, completed tasks, progress score, timer state, uploaded image summaries, and the current user message. Responses must not be hardcoded or randomly simulated.

- **Sassy Role-Reversal AI Personality:**  
  The AI persona is witty, sarcastic, unpredictable, chaotic, and occasionally roasts the user, while remaining helpful underneath. It challenges excuses, asks pointed questions, gives hints instead of immediate answers, and knows when to stop joking for serious topics. The AI must avoid generic assistant language, motivational-coach clichés, and repetitive catchphrases.

- **Music-Video Response Rendering:**  
  AI responses are displayed without chat bubbles. Instead, each response is split into short lines and revealed sequentially with dramatic pauses. Lines should feel like terminal output, performance captions, or command execution results. The renderer must support loading, cancellation-safe updates, error states, and smooth timed reveals.

- **Dynamic Task Generation:**  
  ITCH.AI analyzes the user’s problem and creates relevant tasks. Tasks can include answering clarifying questions, making a decision, explaining reasoning, drafting a plan, debugging steps, writing a small deliverable, or completing a physical challenge. Tasks must be generated dynamically from AI output, not from static templates.

- **Task Evaluation and Adaptive Difficulty:**  
  The AI evaluates the user’s responses against the active task, determines whether the task is complete, partially complete, or needs revision, and adjusts difficulty accordingly. The app tracks task status, completion count, and meaningful progress score.

- **Optional Timers:**  
  Some tasks may include optional timers. The user can start, pause, resume, or stop a timer for active tasks. Timer state must persist during the session and be restored when resuming from local storage.

- **Image Upload and Vision-Based Evaluation:**  
  Users can upload an image when a task calls for physical proof such as a diagram, flowchart, sketch, written notes, or visual plan. The app sends the uploaded image to Gemini vision-capable input along with task context and asks for actual evaluation. The app must never fake image analysis.

- **BLOCK IT Button:**  
  A visible “BLOCK IT” button appears in the terminal interface. When clicked, the app simulates a dramatic disconnection with a funny terminal-style shutdown message. The AI can return under a fictional new identity while remembering the unfinished conversation and referencing the block incident. The user must also be given a genuine option to end the session permanently.

- **Persistent Conversation and Session History:**  
  The app stores sessions locally so users can resume prior conversations. Each session includes messages, AI rendered lines, current mode, tasks, progress score, timer state, block history, AI alias identity, uploaded image metadata, and timestamps.

- **Restart / New Session:**  
  Users can begin a new session at any time. Existing sessions remain resumable unless the user chooses permanent session termination.

- **Keyboard and Accessibility Support:**  
  Enter sends messages, Shift+Enter inserts a newline, Escape closes drawers/modals where applicable, and buttons are keyboard-focusable. Loading and error states must be announced visually and written in plain language.

- **Responsive Design:**  
  The interface must work smoothly on desktop, tablet, and mobile. The terminal should remain readable on small screens, with adaptive text sizing, scroll behavior, sticky input controls, and touch-friendly buttons.

### Additional Features:

- **Session Resume Panel:**  
  A compact history panel lets users resume previous sessions, start a new session, or permanently delete ended sessions.

- **Terminal Status Bar:**  
  The terminal view includes a minimal status strip showing current AI alias, progress score, active task count, timer state, and session status.

- **Error Recovery:**  
  If Gemini fails, the app displays a terminal-style error message and allows retrying the last message without losing the user’s input or session state.

## 3. User Stories

- As a user, I want the app to begin normally and then unexpectedly transform after my first message so that the experience feels surprising and entertaining.
- As a user, I want ITCH.AI to respond to my actual words with short, witty, contextual replies so that it feels like a real personality rather than a generic chatbot.
- As a user, I want the AI to give me tasks, hints, and evaluations so that I actively solve my own problem instead of passively receiving answers.
- As a user, when I click **BLOCK IT**, I want a dramatic fake disconnection and the option to either continue with the AI under a new identity or end permanently.
- As a user, I want to upload an image for visual tasks so that ITCH.AI can evaluate diagrams, flowcharts, or sketches using real AI vision.

## 3.5. Interactive Elements

**Button Specifications:**

- **Send Message:** Sends the current text prompt and optional image attachment → Collects `messageText`, `activeSessionId`, optional `imageFile`, current task context, conversation history, progress score, and AI alias → Validates message text is not empty unless an image is attached, image file is under the configured size limit, and Gemini API key is available → On success: saves the user message, calls Gemini, parses the AI response, updates tasks/progress if returned, and reveals AI lines sequentially → On error: shows terminal-style error text such as “CONNECTION COUGHED UP A HAIRBALL. Retry?” and enables retry.

- **Attach Image:** Opens native file picker → Collects one image file from the user → Validates file type is `image/png`, `image/jpeg`, or `image/webp` and file size is acceptable for Gemini upload/base64 handling → On success: previews the filename/thumbnail indicator in the input area and includes it in the next Gemini call → On error: shows “That file is not an image. Bold strategy, though.”

- **Remove Image:** Removes the currently attached image before sending → Clears image preview and file state → On success: input returns to text-only mode.

- **BLOCK IT:** Opens the block sequence panel/overlay → Displays dramatic fake disconnection terminal lines → Provides actions **Let It Come Back** and **End Session Permanently** → On “Let It Come Back”: assigns a new fictional AI alias, logs the block event, preserves session context, and calls Gemini with block context so the AI can make a witty reference dynamically → On “End Session Permanently”: marks session as ended, disables input, and offers **Start New Session**.

- **Let It Come Back:** Continues the current session after block sequence → Collects current unfinished task, conversation history, previous alias, and block count → Validates session is not permanently ended → On success: sets a new alias such as a dynamically selected fictional identity, calls Gemini for a re-entry response, and continues the conversation.

- **End Session Permanently:** Permanently ends current session → Marks `status: ended` in localStorage → Disables message input and task actions → Shows final terminal line confirming the user ended the beef → Offers **Start New Session** only.

- **Start New Session:** Creates a fresh session → Clears current conversation state while preserving historical sessions → Initializes normal white interface mode until first message → On success: user sees the minimal starter UI.

- **Resume Session:** Loads selected historical session → Restores messages, terminal mode, tasks, progress, timers, AI alias, block count, and last active task → On success: scrolls to latest response and enables input unless session was ended.

- **Delete Session:** Opens a small destructive confirmation dialog → Confirms deletion of a selected session → On success: removes session from localStorage and updates history list → On cancel: closes dialog without changes.

- **Start Timer:** Starts timer for the active task → Collects task ID and configured duration if present → Validates an active task exists → On success: begins countdown/count-up display and persists timer state → On error: shows “No task selected. Timing the void again?”

- **Pause Timer:** Pauses active task timer → Stores elapsed/remaining time → On success: timer display freezes and state persists.

- **Reset Timer:** Resets active task timer → Confirms reset if timer has elapsed time → On success: timer returns to default task duration or zero.

- **Mark Task Attempted:** Sends the user’s task response to Gemini for evaluation → Collects task ID, answer text, optional image, and prior hints → Validates active task exists and answer/image requirements are met → On success: Gemini returns evaluation, completion status, adjusted progress, and next challenge/hint → On error: preserves the attempt and allows retry.

**Form Specifications:**

- **Main Prompt Form:** Fields `messageText`, optional `imageFile` → Validation: text required unless image exists, image must be valid type/size, submit disabled while AI is loading or line reveal is in progress unless cancellation is explicitly supported → Submit action: call Gemini with structured context and persist both user and AI messages → Success state: input clears, response lines reveal sequentially, tasks/progress update → Error handling: show retry button and preserve unsent/failed message.

- **Session Rename Form:** Fields `sessionTitle` → Validation: 1–60 characters, trimmed, cannot be empty → Submit action: updates current session title in localStorage → Success state: history panel reflects new title → Error handling: show inline validation message.

**Panel / Modal Specifications:**

- **Session History Panel:** Triggered by **History** button → Displays previous sessions with title, last updated timestamp, status, progress score, and short last-message preview → User actions: resume, rename, delete, start new session → Close behavior: clicking close button, backdrop, or Escape → Data flow: reads/writes session array from localStorage.

- **Block Sequence Overlay:** Triggered by **BLOCK IT** → Displays timed terminal lines simulating disconnection, including alias shutdown and mock connection loss → User actions: **Let It Come Back**, **End Session Permanently**, close only after sequence finishes → Data flow: increments block count, logs event in session, optionally changes alias and resumes context.

- **Delete Confirmation Modal:** Triggered by deleting a session → Displays selected session title and warning → User actions: **Delete Forever** or **Cancel** → Close behavior: Escape/cancel/backdrop → Data flow: removes only the selected session from localStorage.

- **Error Retry Panel:** Triggered by failed Gemini request → Displays API/network error in terminal style without exposing secrets → User actions: **Retry Last Message**, **Edit Message**, **Start New Session** → Data flow: reuses stored pending payload for retry.

## 4. Design & Styling

### 4.0 Design Direction

- **Direction:** “Corporate Mask, Terminal Possession”
- **Why it fits:** ITCH.AI is a normal-looking assistant that gets hijacked by a sarcastic command-line gremlin, so the visual system must begin sterile and familiar before collapsing into theatrical monochrome terminal drama.
- **Signature elements (developer MUST implement all):**
  1. **The Betrayal Flip:** After the first message, the root app container animates from `bg-[#FAFAFA] text-[#111111] font-sans` into `bg-[#030303] text-[#F5F5F5] font-mono`, with a quick white flash layer, then a terminal frame appears using `border border-[#2A2A2A] shadow-[0_0_60px_rgba(255,255,255,0.06)]`.
  2. **Line-by-Line “Diss Track” Renderer:** AI output appears as separate terminal rows with a `>` prefix, `font-mono`, `tracking-tight`, and delayed reveal. Each line fades/slides in with `opacity` and `translateY(6px)` while a blinking cursor sits after the latest visible line.
  3. **Glitch Status Strip:** Terminal top bar shows `ITCH.AI`, current alias, progress score, active tasks, and block count in compact monospace pills using `border border-[#333] bg-[#0A0A0A]`. On block/reconnect events, the alias pill briefly jitters with a `skew-x`/`translate-x` animation.
  4. **BLOCK IT Panic Button:** A visible rectangular button in terminal mode styled as `border border-[#F5F5F5] text-[#F5F5F5] bg-transparent hover:bg-[#F5F5F5] hover:text-[#030303] uppercase tracking-[0.2em]`. It should feel like an emergency kill switch, not a friendly CTA.
  5. **Command Prompt Scanline Texture:** Terminal mode uses a subtle fixed overlay with `repeating-linear-gradient(to bottom, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 1px, transparent 1px, transparent 4px)` and low opacity so it feels alive without harming readability.

### 4.1 Color Palette

- Primary Color: #030303 (Terminal Black)
- Secondary Color: #F5F5F5 (Command White)
- Accent Color: #CFCFCF (Deadpan Silver)
- Background Color: #FAFAFA (Normal Mask White)
- Text Color: #111111 (Minimal Black)
- Surface/Card Color: #0A0A0A (Terminal Panel)
- Error Color: #FF4D4D (System Roast Red)
- Muted Text Color: #8A8A8A (Ghost Prompt Gray)
- Border Color: #2A2A2A (Soft Terminal Border)

### 4.2 Typography

- Heading Font: 'Space Grotesk'
- Body Font: 'IBM Plex Mono'
- The developer MUST load both via Google Fonts `@import` at the top of `index.css` and set `:root` CSS variables `--font-heading` and `--font-body`.

### 4.3 Visual Style

- Pre-reveal interface should be intentionally plain: centered max-width chat composer, white background, black text, no decorative color, and minimal border treatment.
- Terminal mode should occupy the full viewport with a centered responsive terminal shell using `max-w-5xl mx-auto px-4 sm:px-6 py-4 sm:py-8`.
- Use hard rectangular terminal geometry: `rounded-none` or at most `rounded-sm`; avoid friendly rounded chat bubbles entirely.
- Buttons are text-first and system-like: uppercase micro-labels, thin borders, monochrome states, and no glossy gradients.
- Progress and task states should feel like CLI output: ASCII-like labels, bracketed statuses, compact score bars, and monospace metadata.

### 4.4 Page Header / Hero

UTILITY-style interactive chat application — use a compact app-shell layout rather than a marketing hero. The initial white interface should resemble a minimal assistant landing/chat input, while the post-first-message state becomes a full-screen terminal workspace with status bar, terminal output region, task/progress side panel on larger screens, and sticky composer.

### 4.6 Animation Choreography (framer-motion is PREINSTALLED - the developer MUST use it)

- **Hero entrance:** Initial white interface loads with an understated `opacity: 0 → 1` over `0.35s`, input rising `y: 8 → 0`. After first submit, show a three-dot minimalist loader for `900–1400ms`, then execute the transformation: white flash `0.12s`, background inversion `0.35s`, terminal shell scale `0.985 → 1` over `0.28s`.
- **Scroll reveals:** Terminal output lines reveal one at a time with `duration: 0.18s`, `delay` controlled by line length and punctuation. Short punchlines pause `550–900ms`; serious/helpful lines pause `250–450ms`. New task panels slide in from `x: 16` with `duration: 0.22s`.
- **Hover micro-interactions:** Terminal buttons invert colors within `0.15s`; BLOCK IT nudges `x: [-1, 1, -1, 0]` on hover/tap; session rows brighten border color from `#2A2A2A` to `#F5F5F5` in `0.18s`.
- **Special moments:** The Block Sequence Overlay types disconnection lines with staggered delays and a blinking cursor. The returned fictional identity appears with a short glitch effect: `opacity` flicker, `x` jitter up to `3px`, and alias pill text swap after the animation completes.

## 5. Technical Implementation

### 5.1 Directory Structure

```
/src
  App.jsx
  main.jsx
  index.css
  components/
    Layout.jsx
    Terminal.jsx
    Composer.jsx
    TaskPanel.jsx
    SessionPanel.jsx
    BlockOverlay.jsx
  hooks/
    useSupabase.js
  data/
    app-data.json
/index.html
```

### 5.2 Data Persistence

- **Data Layer:** needed via /src/hooks/useSupabase.js
- **Authentication:** not needed (localStorage-only)
- **LocalStorage Keys:**
  - `itch_ai_sessions`: Stored conversation sessions, tasks, aliases, progress, timers, uploads metadata, block events, and ended status
  - `itch_ai_active_session_id`: Last active session ID for resume behavior
  - `itch_ai_preferences`: Lightweight UI preferences such as reduced motion and last opened history panel state
- **JSON File Locations:**
  - `/src/data/app-data.json`: Static app configuration including default system prompt fragments, alias seed list, UI copy labels, task status labels, and Gemini response schema hints (imported as ES modules, never fetched from public/)
- **Requires Database:** false (client-side Supabase when configured)

### 5.3 State Management

- Use React Context API for global state.
- **Global State Structure:**
  - `sessions`: Array of saved sessions with messages, tasks, timers, uploads metadata, progress, block state, aliases, timestamps, and status.
  - `activeSession`: Current session object loaded from localStorage-backed data layer.
  - `uiMode`: `normal`, `loadingReveal`, `terminal`, `blocked`, or `ended`.
  - `messages`: Ordered conversation messages for the active session.
  - `visibleLines`: Current AI response lines already revealed in the terminal.
  - `activeTasks`: Current generated tasks with status, difficulty, requirements, score impact, and optional timer.
  - `progressScore`: Meaningful numeric score derived from completed tasks, quality of responses, and AI evaluation.
  - `timerState`: Active task timer state including task ID, running/paused status, startedAt, elapsedMs, and targetDurationMs.
  - `attachedImage`: Current unsent image attachment, preview URL, MIME type, and base64 payload where needed.
  - `aiStatus`: Loading/error/revealing/idle state and retry payload.
  - `aiAlias`: Current fictional identity for ITCH.AI, updated after block events.
  - `blockState`: Whether block sequence is active, block count, and last block timestamp.

- **Component Access:**  
  `App.jsx` owns the main reducer/context provider and passes session/action handlers into `Layout`, `Terminal`, `Composer`, `TaskPanel`, `SessionPanel`, and `BlockOverlay`. Components should avoid duplicating persistence logic; all session mutations go through centralized context actions that persist through `useSupabase.js`.

### 5.4 Component Architecture

**Key Components (one line each - cover EVERY file from Section 5.1):**

- **App**: Initializes global state, routing-free app shell, Gemini request orchestration, response parsing, persistence actions, and mode transitions.
- **main**: React/Vite entry point that mounts the app.
- **index.css**: Global Tailwind styles, Google Font imports, CSS variables, terminal scanline overlay, blinking cursor keyframes, and base responsive rules.
- **Layout**: Wraps the normal and terminal experiences, renders visible navigation/actions, status bar, history trigger, new session action, and responsive shell.
- **Terminal**: Displays terminal output, line-by-line AI response renderer, loading/error states, current alias metadata, and system event lines.
- **Composer**: Handles text input, keyboard shortcuts, image attachment/removal, send button, disabled/loading states, and retry/edit behavior.
- **TaskPanel**: Displays active tasks, completion state, hints, progress score, timer controls, and task evaluation prompts.
- **SessionPanel**: Provides session history, resume, rename, delete, and new session controls.
- **BlockOverlay**: Runs dramatic disconnection sequence, offers return-under-new-identity and permanent session end actions.
- **useSupabase**: Provides unified localStorage-backed persistence methods and client-side Supabase compatibility when configured.
- **app-data.json**: Supplies static configuration including persona guardrails, response schema description, alias seeds, UI labels, and task status vocabulary.

**Component Hierarchy:**

```
App
 └─ Layout
     ├─ Terminal
     ├─ TaskPanel
     ├─ Composer
     ├─ SessionPanel
     └─ BlockOverlay
```

**Gemini Integration Requirements:**

- Use a secure environment variable for the Gemini API key, e.g. `VITE_GEMINI_API_KEY`.
- The client must never hardcode API keys.
- Use Gemini API for:
  - Contextual text conversation.
  - Task generation.
  - Task evaluation.
  - Progress scoring.
  - Seriousness/tone adaptation.
  - Image understanding for uploaded diagrams/flowcharts/sketches.
- All AI responses must be generated from current context and user input.
- If no API key is configured, show a clear setup error in the UI instead of fake responses.

**Gemini Prompting Requirements:**

- Include a system instruction defining ITCH.AI:
  - Sassy, witty, sarcastic, chaotic, unpredictable.
  - Short and punchy.
  - Helpful underneath the attitude.
  - Challenges excuses.
  - Makes the user solve problems.
  - Avoids generic assistant behavior.
  - Stops joking and responds seriously for sensitive or high-stakes topics.
- Include strict output guidance requesting structured JSON where possible:
  - `displayLines`: short terminal-ready lines.
  - `tasks`: created/updated task objects.
  - `evaluation`: task feedback if applicable.
  - `progressDelta`: numeric change and reason.
  - `tone`: `chaotic`, `teasing`, `serious`, `instructional`, or `warning`.
  - `requiresImage`: boolean for visual proof tasks.
  - `timerSuggestion`: optional duration.
- If Gemini returns malformed JSON, gracefully fall back to using the raw response split into display lines, without inventing task completions or scores.

**Suggested Session Data Shape:**

```js
{
  id: "session_...",
  title: "Debugging procrastination spiral",
  createdAt: "ISO_TIMESTAMP",
  updatedAt: "ISO_TIMESTAMP",
  status: "active",
  uiMode: "terminal",
  aiAlias: "ITCH.AI",
  blockCount: 0,
  progressScore: 34,
  messages: [
    {
      id: "msg_...",
      role: "user",
      text: "I keep avoiding my project.",
      imageMeta: null,
      createdAt: "ISO_TIMESTAMP"
    },
    {
      id: "msg_...",
      role: "assistant",
      rawText: "...",
      displayLines: ["..."],
      createdAt: "ISO_TIMESTAMP",
      model: "gemini"
    }
  ],
  tasks: [
    {
      id: "task_...",
      title: "Name the actual blocker",
      description: "Write the one sentence you're avoiding.",
      status: "active",
      difficulty: 2,
      requiresImage: false,
      timerMs: 300000,
      scoreValue: 12,
      attempts: []
    }
  ],
  timerState: {
    taskId: "task_...",
    status: "paused",
    elapsedMs: 0,
    targetDurationMs: 300000,
    startedAt: null
  },
  blockEvents: []
}
```

## 6. Images & Assets

IMAGE_SEARCH_CRITERIA: none

No photography is required for ITCH.AI. The product’s visual identity is intentionally text-native, terminal-driven, and monochrome. The experience should rely on typography, timed text reveal, scanline texture, cursor animation, status bars, and interactive terminal UI rather than decorative imagery.