CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL DEFAULT 'Untitled beef',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  status TEXT NOT NULL DEFAULT 'active',
  ui_mode TEXT NOT NULL DEFAULT 'normal',
  ai_alias TEXT NOT NULL DEFAULT 'ITCH.AI',
  block_count INTEGER NOT NULL DEFAULT 0,
  progress_score INTEGER NOT NULL DEFAULT 0,
  messages JSONB NOT NULL DEFAULT '[]'::jsonb,
  tasks JSONB NOT NULL DEFAULT '[]'::jsonb,
  timer_state JSONB NOT NULL DEFAULT '{}'::jsonb,
  block_events JSONB NOT NULL DEFAULT '[]'::jsonb,
  uploads JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS active_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_key TEXT UNIQUE NOT NULL DEFAULT 'default',
  active_session_id TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS app_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  preference_key TEXT UNIQUE NOT NULL DEFAULT 'default',
  preference_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS static_app_data (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  data_key TEXT UNIQUE NOT NULL,
  app_name TEXT NOT NULL,
  storage_keys JSONB NOT NULL DEFAULT '{}'::jsonb,
  limits JSONB NOT NULL DEFAULT '{}'::jsonb,
  default_alias TEXT NOT NULL,
  alias_seeds JSONB NOT NULL DEFAULT '[]'::jsonb,
  block_lines JSONB NOT NULL DEFAULT '[]'::jsonb,
  normal_mode JSONB NOT NULL DEFAULT '{}'::jsonb,
  labels JSONB NOT NULL DEFAULT '{}'::jsonb,
  task_status_labels JSONB NOT NULL DEFAULT '{}'::jsonb,
  system_prompt_fragments JSONB NOT NULL DEFAULT '[]'::jsonb,
  response_schema_hint JSONB NOT NULL DEFAULT '{}'::jsonb,
  gemini JSONB NOT NULL DEFAULT '{}'::jsonb,
  errors JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
