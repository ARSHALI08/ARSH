import { useRef, useState } from 'react';
import { ImagePlus, Send, X, RefreshCw, Edit3 } from 'lucide-react';
import { motion } from 'framer-motion';
import appData from '../data/app-data.json';

const acceptedTypes = ['image/png', 'image/jpeg', 'image/webp'];

const readFileAsDataUrl = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Image read failed'));
    reader.readAsDataURL(file);
  });

export default function Composer({
  mode,
  disabled,
  isLoading,
  isRevealing,
  attachedImage,
  error,
  initialText,
  onSend,
  onAttachImage,
  onRemoveImage,
  onRetry,
  onEditLastMessage
}) {
  const [messageText, setMessageText] = useState(initialText || '');
  const [localError, setLocalError] = useState('');
  const fileInputRef = useRef(null);
  const textareaRef = useRef(null);

  const terminalMode = mode !== 'normal';
  const submitDisabled = disabled || isLoading || isRevealing;

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLocalError('');

    if (!messageText.trim() && !attachedImage) {
      setLocalError(appData.errors.emptyMessage);
      textareaRef.current?.focus();
      return;
    }

    await onSend(messageText);
    setMessageText('');
  };

  const handleKeyDown = async (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (!submitDisabled) {
        await handleSubmit(event);
      }
    }
  };

  const handleFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';

    if (!file) return;

    if (!acceptedTypes.includes(file.type)) {
      setLocalError(appData.errors.badImage);
      return;
    }

    if (file.size > appData.limits.maxImageBytes) {
      setLocalError(appData.errors.largeImage);
      return;
    }

    const dataUrl = await readFileAsDataUrl(file);
    const base64 = dataUrl.split(',')[1] || '';

    onAttachImage({
      name: file.name,
      type: file.type,
      size: file.size,
      base64,
      previewUrl: dataUrl,
      createdAt: new Date().toISOString()
    });
    setLocalError('');
  };

  const shellClass = terminalMode
    ? 'border-[#2A2A2A] bg-[#050505] text-[#F5F5F5]'
    : 'border-[#D8D8D8] bg-white text-[#111111] shadow-[0_12px_40px_rgba(0,0,0,0.05)]';

  const inputClass = terminalMode
    ? 'bg-transparent text-[#F5F5F5] placeholder:text-[#8A8A8A] caret-[#F5F5F5]'
    : 'bg-transparent text-[#111111] placeholder:text-[#737373] caret-[#111111]';

  const buttonBase =
    'inline-flex min-h-11 items-center justify-center gap-2 border px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] transition duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-40';

  return (
    <form onSubmit={handleSubmit} className={`w-full border ${shellClass}`}>
      {(error || localError) && (
        <div className={`border-b px-4 py-3 text-xs ${terminalMode ? 'border-[#2A2A2A] text-[#FF4D4D]' : 'border-[#E5E5E5] text-[#9F1D1D]'}`}>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <span>{localError || error}</span>
            {error && (
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={onRetry}
                  className={`${buttonBase} ${terminalMode ? 'border-[#F5F5F5] text-[#F5F5F5] hover:bg-[#F5F5F5] hover:text-[#030303] focus:ring-[#F5F5F5] focus:ring-offset-[#030303]' : 'border-[#111111] text-[#111111] hover:bg-[#111111] hover:text-white focus:ring-[#111111]'}`}
                >
                  <RefreshCw size={14} />
                  {appData.labels.retry}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onEditLastMessage();
                    textareaRef.current?.focus();
                  }}
                  className={`${buttonBase} ${terminalMode ? 'border-[#333] text-[#CFCFCF] hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:ring-[#F5F5F5] focus:ring-offset-[#030303]' : 'border-[#CFCFCF] text-[#111111] hover:border-[#111111] focus:ring-[#111111]'}`}
                >
                  <Edit3 size={14} />
                  {appData.labels.edit}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {attachedImage && (
        <div className={`flex items-center justify-between border-b px-4 py-3 text-xs ${terminalMode ? 'border-[#2A2A2A] text-[#CFCFCF]' : 'border-[#E5E5E5] text-[#111111]'}`}>
          <div className="flex min-w-0 items-center gap-3">
            <div className={`h-9 w-9 border ${terminalMode ? 'border-[#333] bg-[#0A0A0A]' : 'border-[#D8D8D8] bg-[#FAFAFA]'}`}>
              {attachedImage.previewUrl ? (
                <img src={attachedImage.previewUrl} alt="" className="h-full w-full object-cover" />
              ) : null}
            </div>
            <span className="truncate">{attachedImage.name}</span>
          </div>
          <button
            type="button"
            onClick={onRemoveImage}
            className={`inline-flex min-h-11 items-center gap-2 px-3 text-xs uppercase tracking-[0.16em] transition duration-150 focus:outline-none focus:ring-2 ${terminalMode ? 'text-[#8A8A8A] hover:text-[#F5F5F5] focus:ring-[#F5F5F5]' : 'text-[#555] hover:text-[#111111] focus:ring-[#111111]'}`}
          >
            <X size={15} />
            {appData.labels.removeImage}
          </button>
        </div>
      )}

      <div className="flex flex-col gap-3 p-3 sm:flex-row sm:items-end">
        <textarea
          ref={textareaRef}
          value={messageText}
          onChange={(event) => setMessageText(event.target.value)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          rows={mode === 'normal' ? 2 : 3}
          placeholder={mode === 'normal' ? appData.normalMode.placeholder : 'C:\\ITCH> type your excuse here...'}
          className={`min-h-[72px] flex-1 resize-none px-2 py-2 font-body text-sm leading-relaxed outline-none disabled:cursor-not-allowed disabled:opacity-50 ${inputClass}`}
          aria-label="Message text"
        />

        <div className="flex shrink-0 gap-2">
          <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={handleFile} className="hidden" />
          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            disabled={disabled}
            onClick={() => fileInputRef.current?.click()}
            className={`${buttonBase} ${terminalMode ? 'border-[#333] text-[#CFCFCF] hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:ring-[#F5F5F5] focus:ring-offset-[#030303]' : 'border-[#D8D8D8] text-[#111111] hover:border-[#111111] focus:ring-[#111111]'}`}
          >
            <ImagePlus size={16} />
            <span className="hidden sm:inline">{appData.labels.attach}</span>
          </motion.button>

          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={submitDisabled}
            className={`${buttonBase} ${terminalMode ? 'border-[#F5F5F5] bg-[#F5F5F5] text-[#030303] hover:bg-transparent hover:text-[#F5F5F5] focus:ring-[#F5F5F5] focus:ring-offset-[#030303]' : 'border-[#111111] bg-[#111111] text-white hover:bg-white hover:text-[#111111] focus:ring-[#111111]'}`}
          >
            <Send size={16} />
            {isLoading || isRevealing ? 'Busy' : appData.labels.send}
          </motion.button>
        </div>
      </div>
    </form>
  );
}
