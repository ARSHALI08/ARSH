import { History, Plus, ShieldAlert, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import appData from '../data/app-data.json';
import Terminal from './Terminal.jsx';
import TaskPanel from './TaskPanel.jsx';
import Composer from './Composer.jsx';
import SessionPanel from './SessionPanel.jsx';
import BlockOverlay from './BlockOverlay.jsx';

export default function Layout({
  activeSession,
  sessions,
  uiMode,
  messages,
  visibleLineCounts,
  tasks,
  progressScore,
  timerState,
  attachedImage,
  aiStatus,
  historyOpen,
  flashActive,
  aliasGlitch,
  onOpenHistory,
  onCloseHistory,
  onStartNewSession,
  onResumeSession,
  onRenameSession,
  onDeleteSession,
  onSend,
  onAttachImage,
  onRemoveImage,
  onRetry,
  onEditLastMessage,
  onStartTimer,
  onPauseTimer,
  onResetTimer,
  onSubmitAttempt,
  onOpenBlock,
  onLetBack,
  onEndSession
}) {
  const terminalMode = uiMode !== 'normal' && uiMode !== 'loadingReveal';
  const isEnded = activeSession?.status === 'ended' || uiMode === 'ended';
  const activeTaskCount = Array.isArray(tasks) ? tasks.filter((task) => task.status !== 'complete').length : 0;
  const aiAlias = activeSession?.aiAlias || appData.defaultAlias;
  const blockCount = activeSession?.blockCount || 0;

  if (!terminalMode) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] text-[#111111]">
        {flashActive && <div className="white-flash" />}
        <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 py-5 sm:px-6">
          <header className="flex items-center justify-between">
            <div className="font-heading text-sm font-semibold uppercase tracking-[0.24em]">{appData.normalMode.eyebrow}</div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenHistory}
                className="inline-flex min-h-11 items-center gap-2 border border-[#D8D8D8] bg-white px-3 text-xs font-semibold uppercase tracking-[0.16em] transition duration-150 hover:border-[#111111] focus:outline-none focus:ring-2 focus:ring-[#111111]"
              >
                <History size={15} />
                {appData.labels.history}
              </button>
              <button
                type="button"
                onClick={onStartNewSession}
                className="inline-flex min-h-11 items-center gap-2 border border-[#111111] bg-[#111111] px-3 text-xs font-semibold uppercase tracking-[0.16em] text-white transition duration-150 hover:bg-white hover:text-[#111111] focus:outline-none focus:ring-2 focus:ring-[#111111]"
              >
                <Plus size={15} />
                <span className="hidden sm:inline">{appData.labels.newSession}</span>
              </button>
            </div>
          </header>

          <motion.main
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.35 }}
            className="flex flex-1 items-center justify-center py-12"
          >
            <div className="w-full">
              <div className="mb-8 text-center">
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: 0.05 }}
                  className="mx-auto mb-6 flex h-14 w-14 items-center justify-center border border-[#111111] bg-white"
                >
                  <Sparkles size={22} />
                </motion.div>
                <h1 className="font-heading text-4xl font-semibold tracking-tight sm:text-6xl">{appData.normalMode.headline}</h1>
                <p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-[#555]">{appData.normalMode.subcopy}</p>
              </div>

              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: 0.12 }}>
                {uiMode === 'loadingReveal' && (
                  <div className="mb-3 border border-[#111111] bg-white px-4 py-3 font-body text-xs uppercase tracking-[0.18em]">
                    Pleasant interface destabilizing<span className="normal-dots" />
                  </div>
                )}
                <Composer
                  mode="normal"
                  disabled={uiMode === 'loadingReveal'}
                  isLoading={uiMode === 'loadingReveal'}
                  isRevealing={false}
                  attachedImage={attachedImage}
                  error={aiStatus.status === 'error' ? aiStatus.error : ''}
                  onSend={onSend}
                  onAttachImage={onAttachImage}
                  onRemoveImage={onRemoveImage}
                  onRetry={onRetry}
                  onEditLastMessage={onEditLastMessage}
                />
              </motion.div>
            </div>
          </motion.main>
        </div>

        <SessionPanel
          open={historyOpen}
          sessions={sessions}
          activeSessionId={activeSession?.id}
          onClose={onCloseHistory}
          onResume={onResumeSession}
          onRename={onRenameSession}
          onDelete={onDeleteSession}
          onStartNew={onStartNewSession}
        />
      </div>
    );
  }

  return (
    <div className="terminal-root min-h-screen bg-[#030303] text-[#F5F5F5]">
      {flashActive && <div className="white-flash" />}
      <div className="scanline-overlay" />

      <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 py-4 sm:px-6 sm:py-8">
        <header className="mb-4 border border-[#2A2A2A] bg-[#0A0A0A]">
          <div className="flex flex-col gap-3 px-3 py-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              <span className="border border-[#333] bg-[#050505] px-3 py-2 font-heading text-xs font-semibold uppercase tracking-[0.22em] text-[#F5F5F5]">
                ITCH.AI
              </span>
              <span className={`alias-pill border border-[#333] bg-[#050505] px-3 py-2 font-body text-xs uppercase tracking-[0.16em] text-[#CFCFCF] ${aliasGlitch ? 'glitch-jitter' : ''}`}>
                alias: {aiAlias}
              </span>
              <span className="border border-[#333] bg-[#050505] px-3 py-2 font-body text-xs uppercase tracking-[0.16em] text-[#CFCFCF]">
                score: {progressScore || 0}
              </span>
              <span className="border border-[#333] bg-[#050505] px-3 py-2 font-body text-xs uppercase tracking-[0.16em] text-[#CFCFCF]">
                tasks: {activeTaskCount}
              </span>
              <span className="border border-[#333] bg-[#050505] px-3 py-2 font-body text-xs uppercase tracking-[0.16em] text-[#CFCFCF]">
                blocks: {blockCount}
              </span>
              <span className="border border-[#333] bg-[#050505] px-3 py-2 font-body text-xs uppercase tracking-[0.16em] text-[#CFCFCF]">
                timer: {timerState?.status || 'idle'}
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={onOpenHistory}
                className="inline-flex min-h-11 items-center justify-center gap-2 border border-[#333] bg-transparent px-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
              >
                <History size={15} />
                {appData.labels.history}
              </button>
              <button
                type="button"
                onClick={onStartNewSession}
                className="inline-flex min-h-11 items-center justify-center gap-2 border border-[#333] bg-transparent px-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
              >
                <Plus size={15} />
                New
              </button>
              {!isEnded && (
                <motion.button
                  whileHover={{ x: [-1, 1, -1, 0] }}
                  whileTap={{ x: [-1, 1, -1, 0], scale: 0.98 }}
                  type="button"
                  onClick={onOpenBlock}
                  className="inline-flex min-h-11 items-center justify-center gap-2 border border-[#F5F5F5] bg-transparent px-4 text-xs font-semibold uppercase tracking-[0.2em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                >
                  <ShieldAlert size={15} />
                  {appData.labels.block}
                </motion.button>
              )}
            </div>
          </div>
        </header>

        {isEnded && (
          <div className="mb-4 border border-[#FF4D4D] bg-[#160404] px-4 py-3 font-body text-sm text-[#F5F5F5]">
            <span className="mr-2 text-[#FF4D4D]">&gt;</span>
            SESSION ENDED. The beef has been buried in a shallow localStorage grave. Start a new session to continue.
          </div>
        )}

        <main className="grid flex-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div className="flex min-w-0 flex-col gap-4">
            <Terminal
              messages={messages}
              visibleLineCounts={visibleLineCounts}
              aiStatus={aiStatus}
              aiAlias={aiAlias}
              mode={uiMode}
              onRetry={onRetry}
              onStartNewSession={onStartNewSession}
            />

            <div className="sticky bottom-0 z-20 bg-[#030303] pb-1 pt-2">
              <Composer
                mode="terminal"
                disabled={isEnded}
                isLoading={aiStatus.status === 'loading'}
                isRevealing={aiStatus.status === 'revealing'}
                attachedImage={attachedImage}
                error={aiStatus.status === 'error' ? aiStatus.error : ''}
                onSend={onSend}
                onAttachImage={onAttachImage}
                onRemoveImage={onRemoveImage}
                onRetry={onRetry}
                onEditLastMessage={onEditLastMessage}
              />
            </div>
          </div>

          <TaskPanel
            tasks={tasks}
            progressScore={progressScore}
            timerState={timerState}
            disabled={isEnded || aiStatus.status === 'loading' || aiStatus.status === 'revealing'}
            onStartTimer={onStartTimer}
            onPauseTimer={onPauseTimer}
            onResetTimer={onResetTimer}
            onSubmitAttempt={onSubmitAttempt}
          />
        </main>
      </div>

      <SessionPanel
        open={historyOpen}
        sessions={sessions}
        activeSessionId={activeSession?.id}
        onClose={onCloseHistory}
        onResume={onResumeSession}
        onRename={onRenameSession}
        onDelete={onDeleteSession}
        onStartNew={onStartNewSession}
      />

      <BlockOverlay open={uiMode === 'blocked'} alias={aiAlias} onLetBack={onLetBack} onEndSession={onEndSession} />
    </div>
  );
}
