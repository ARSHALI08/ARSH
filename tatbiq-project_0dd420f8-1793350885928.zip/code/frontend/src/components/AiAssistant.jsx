import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertCircle, HelpCircle, Loader2, MessageSquare, RotateCcw, Send, X } from 'lucide-react';
import toast from 'react-hot-toast';
import appData from '../data/app-data.json';

const STORAGE_KEY = 'itch_ai_assistant_history';
const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

const extractGeminiText = (data) => {
  const parts = data?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  return parts.map((part) => part.text || '').join('\n').trim();
};

const pause = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const revealText = async (text, onStep) => {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  let accumulated = '';

  for (const word of words) {
    accumulated = accumulated ? `${accumulated} ${word}` : word;
    onStep(accumulated);
    await pause(22);
  }
};

const askDirectGemini = async ({ input, history, instructions }) => {
  if (!apiKey) {
    throw new Error(appData.errors.noApiKey);
  }

  const contents = [
    ...(Array.isArray(history) ? history : []).map((message) => ({
      role: message.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: message.text }]
    })),
    {
      role: 'user',
      parts: [{ text: input }]
    }
  ];

  const response = await fetch(`${appData.gemini.endpoint}?key=${encodeURIComponent(apiKey)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: {
        parts: [{ text: instructions }]
      },
      contents,
      generationConfig: {
        temperature: 0.65,
        topP: 0.9,
        maxOutputTokens: 700
      }
    })
  });

  if (!response.ok) {
    throw new Error(appData.errors.generic);
  }

  const data = await response.json();
  const text = extractGeminiText(data);

  if (!text) {
    throw new Error(appData.errors.generic);
  }

  return text;
};

const instructions = `You are a helpful assistant for ITCH.AI, a terminal-style productivity app with attitude.

Your role is to help visitors understand:
- The terminal interface: how messages appear line by line, the retro aesthetic, and navigation
- The task system: how tasks are created by the AI, tracked, timed, and submitted for evaluation
- Session management: creating new sessions, resuming old ones, the history panel, and session states
- The BLOCK IT feature: what happens when you block the AI and let it come back with a new alias
- Progress scoring: how points are earned by completing tasks

Keep answers short, clear, and friendly. Match the app's slightly irreverent tone but stay helpful.
If asked about something unrelated to the app, politely redirect to app-related topics.`;

const loadHistory = () => {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const saveHistory = (history) => {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch {
    // Storage full or unavailable
  }
};

export default function AiAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState(null);
  const [streamingText, setStreamingText] = useState('');

  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) {
      setMessages(loadHistory());
      inputRef.current?.focus();
    }
  }, [open]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, streamingText]);

  const clearChat = useCallback(() => {
    setMessages([]);
    setStreamingText('');
    setError(null);
    sessionStorage.removeItem(STORAGE_KEY);
    toast.success('Chat cleared.');
  }, []);

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || status === 'loading') return;

    setInput('');
    setError(null);
    setStreamingText('');

    const userMessage = { role: 'user', text };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    saveHistory(updatedMessages);

    setStatus('loading');

    try {
      let fullText = '';
      const history = updatedMessages.slice(0, -1).map((m) => ({
        role: m.role,
        text: m.text
      }));

      fullText = await askDirectGemini({
        input: text,
        history,
        instructions
      });

      await revealText(fullText, setStreamingText);

      const assistantMessage = { role: 'assistant', text: fullText };
      const finalMessages = [...updatedMessages, assistantMessage];
      setMessages(finalMessages);
      saveHistory(finalMessages);
      setStreamingText('');
      setStatus('idle');
    } catch (err) {
      setStatus('error');
      setError({
        message: err instanceof Error ? err.message : 'Something went wrong. Please try again.',
        code: 'direct_gemini'
      });
    }
  }, [input, messages, status]);

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSend();
    }
  };

  const handleRetry = useCallback(() => {
    if (messages.length === 0) return;
    const lastUserIndex = messages.map((m) => m.role).lastIndexOf('user');
    if (lastUserIndex === -1) return;

    const lastUserMessage = messages[lastUserIndex];
    const messagesBeforeRetry = messages.slice(0, lastUserIndex);
    setMessages(messagesBeforeRetry);
    saveHistory(messagesBeforeRetry);
    setInput(lastUserMessage.text);
    setError(null);
    setStatus('idle');
    inputRef.current?.focus();
  }, [messages]);

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full border border-[#2A2A2A] bg-[#0A0A0A] text-[#F5F5F5] shadow-[0_4px_24px_rgba(0,0,0,0.4)] transition-colors duration-150 hover:border-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
        aria-label="Open AI assistant"
      >
        <HelpCircle size={24} />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.96 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-5 z-50 flex h-[480px] w-[360px] max-w-[calc(100vw-40px)] flex-col border border-[#2A2A2A] bg-[#030303] shadow-[0_8px_48px_rgba(0,0,0,0.5)]"
          >
            <header className="flex items-center justify-between border-b border-[#2A2A2A] bg-[#0A0A0A] px-4 py-3">
              <div className="flex items-center gap-2">
                <MessageSquare size={16} className="text-[#F5F5F5]" />
                <span className="font-heading text-sm font-semibold uppercase tracking-[0.16em] text-[#F5F5F5]">
                  Assistant
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={clearChat}
                  className="flex h-9 w-9 items-center justify-center text-[#8A8A8A] transition-colors duration-150 hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                  aria-label="New chat"
                  title="New chat"
                >
                  <RotateCcw size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="flex h-9 w-9 items-center justify-center text-[#8A8A8A] transition-colors duration-150 hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                  aria-label="Close assistant"
                >
                  <X size={18} />
                </button>
              </div>
            </header>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 terminal-scroll">
              {messages.length === 0 && !streamingText && status !== 'loading' && (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <HelpCircle size={32} className="mb-3 text-[#8A8A8A]" />
                  <p className="text-sm text-[#8A8A8A]">
                    Ask me about the terminal, tasks, sessions, or anything else about ITCH.AI.
                  </p>
                </div>
              )}

              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`text-sm leading-relaxed ${
                      message.role === 'user'
                        ? 'border-l-2 border-[#F5F5F5] pl-3 text-[#F5F5F5]'
                        : 'text-[#CFCFCF]'
                    }`}
                  >
                    {message.role === 'assistant' && (
                      <span className="mr-2 text-[#8A8A8A]">&gt;</span>
                    )}
                    {message.text}
                  </div>
                ))}

                {streamingText && (
                  <div className="text-sm leading-relaxed text-[#CFCFCF]">
                    <span className="mr-2 text-[#8A8A8A]">&gt;</span>
                    {streamingText}
                    <span className="terminal-cursor ml-1" />
                  </div>
                )}

                {status === 'loading' && !streamingText && (
                  <div className="flex items-center gap-2 text-sm text-[#8A8A8A]">
                    <Loader2 size={14} className="animate-spin" />
                    <span>Thinking<span className="terminal-dots" /></span>
                  </div>
                )}

                {error && (
                  <div className="border border-[#FF4D4D] bg-[#160404] p-3 text-sm">
                    <div className="mb-2 flex items-center gap-2 text-[#FF4D4D]">
                      <AlertCircle size={14} />
                      <span>Error</span>
                    </div>
                    <p className="mb-3 text-[#F5F5F5]">{error.message}</p>
                    <button
                      type="button"
                      onClick={handleRetry}
                      className="inline-flex items-center gap-2 border border-[#F5F5F5] px-3 py-2 text-xs uppercase tracking-[0.14em] text-[#F5F5F5] transition-colors duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                    >
                      <RotateCcw size={12} />
                      Retry
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="border-t border-[#2A2A2A] p-3">
              <div className="flex gap-2">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  disabled={status === 'loading'}
                  rows={1}
                  placeholder="Ask about the app..."
                  className="min-h-[44px] flex-1 resize-none border border-[#2A2A2A] bg-[#050505] px-3 py-3 font-body text-sm text-[#F5F5F5] outline-none placeholder:text-[#666] focus:border-[#F5F5F5] disabled:opacity-50"
                />
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  type="button"
                  onClick={handleSend}
                  disabled={status === 'loading' || !input.trim()}
                  className="flex h-11 w-11 items-center justify-center border border-[#F5F5F5] bg-[#F5F5F5] text-[#030303] transition-colors duration-150 hover:bg-transparent hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                  aria-label="Send message"
                >
                  <Send size={16} />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
