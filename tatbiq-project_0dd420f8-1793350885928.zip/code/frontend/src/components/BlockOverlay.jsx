import { useEffect, useState } from 'react';
import { Ban, Power, RotateCcw } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import appData from '../data/app-data.json';

export default function BlockOverlay({
  open,
  alias,
  onLetBack,
  onEndSession
}) {
  const [visibleCount, setVisibleCount] = useState(0);
  const blockLines = Array.isArray(appData.blockLines) ? appData.blockLines : [];

  useEffect(() => {
    if (!open) {
      setVisibleCount(0);
      return undefined;
    }

    const timers = blockLines.map((line, index) =>
      window.setTimeout(() => {
        setVisibleCount(index + 1);
      }, 280 + index * 520)
    );

    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [open, blockLines]);

  const sequenceFinished = visibleCount >= blockLines.length;
  const visibleLines = blockLines.slice(0, visibleCount);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#030303]/95 p-4 text-[#F5F5F5]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label="Block sequence"
        >
          <motion.div
            initial={{ scale: 0.985, y: 8 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.985, y: 8 }}
            transition={{ duration: 0.22 }}
            className="w-full max-w-3xl border border-[#2A2A2A] bg-[#050505] shadow-[0_0_80px_rgba(255,255,255,0.08)]"
          >
            <header className="flex items-center justify-between border-b border-[#2A2A2A] bg-[#0A0A0A] px-4 py-3">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em]">
                <Ban size={16} />
                BLOCK SEQUENCE
              </div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-[#8A8A8A]">TARGET: {alias}</div>
            </header>

            <div className="min-h-[300px] p-5 font-body text-sm leading-relaxed">
              <div className="space-y-3">
                {visibleLines.map((line) => (
                  <motion.div
                    key={line}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.18 }}
                  >
                    <span className="mr-2 text-[#8A8A8A]">&gt;</span>
                    {line}
                  </motion.div>
                ))}
                {!sequenceFinished && <span className="terminal-cursor ml-5" />}
              </div>
            </div>

            <footer className="border-t border-[#2A2A2A] p-4">
              <div className="flex flex-col gap-3 sm:flex-row">
                <motion.button
                  whileHover={sequenceFinished ? { x: [-1, 1, -1, 0] } : undefined}
                  whileTap={sequenceFinished ? { scale: 0.98 } : undefined}
                  type="button"
                  disabled={!sequenceFinished}
                  onClick={onLetBack}
                  className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 border border-[#F5F5F5] px-4 text-xs font-semibold uppercase tracking-[0.18em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:cursor-not-allowed disabled:opacity-30"
                >
                  <RotateCcw size={15} />
                  {appData.labels.letBack}
                </motion.button>
                <button
                  type="button"
                  disabled={!sequenceFinished}
                  onClick={onEndSession}
                  className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 border border-[#FF4D4D] px-4 text-xs font-semibold uppercase tracking-[0.18em] text-[#FF4D4D] transition duration-150 hover:bg-[#FF4D4D] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#FF4D4D] disabled:cursor-not-allowed disabled:opacity-30"
                >
                  <Power size={15} />
                  {appData.labels.endSession}
                </button>
              </div>
            </footer>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
