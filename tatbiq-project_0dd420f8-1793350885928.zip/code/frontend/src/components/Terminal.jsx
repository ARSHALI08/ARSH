import { useEffect, useRef } from 'react';
import { AlertTriangle, Loader2, TerminalSquare } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const lineVariants = {
  hidden: { opacity: 0, y: 6 },
  visible: { opacity: 1, y: 0 }
};

export default function Terminal({
  messages,
  visibleLineCounts,
  aiStatus,
  aiAlias,
  mode,
  onRetry,
  onStartNewSession
}) {
  const scrollRef = useRef(null);
  const terminalMode = mode !== 'normal';

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: 'smooth'
    });
  }, [messages, visibleLineCounts, aiStatus.status]);

  if (!terminalMode) return null;

  const safeMessages = Array.isArray(messages) ? messages : [];

  return (
    <section className="relative flex min-h-[56vh] flex-1 flex-col border border-[#2A2A2A] bg-[#030303] shadow-[0_0_60px_rgba(255,255,255,0.06)]">
      <div className="flex items-center justify-between border-b border-[#2A2A2A] bg-[#0A0A0A] px-3 py-2 text-[11px] uppercase tracking-[0.18em] text-[#8A8A8A]">
        <div className="flex items-center gap-2">
          <TerminalSquare size={14} className="text-[#F5F5F5]" />
          <span>C:\ITCH\SESSION</span>
        </div>
        <span>{aiAlias}</span>
      </div>

      <div ref={scrollRef} className="terminal-scroll relative max-h-[58vh] min-h-[420px] overflow-y-auto px-4 py-4 sm:px-5">
        <div className="space-y-3 font-body text-sm leading-relaxed tracking-tight text-[#F5F5F5]">
          <div className="text-[#8A8A8A]">
            <span className="text-[#CFCFCF]">&gt;</span> BOOTING HOSTILE HELPFULNESS LAYER...
          </div>

          {safeMessages.length === 0 && (
            <div className="border border-dashed border-[#2A2A2A] bg-[#050505] p-4 text-[#8A8A8A]">
              <span className="text-[#CFCFCF]">&gt;</span> TERMINAL WAITING. SAY SOMETHING WORTH INTERRUPTING.
            </div>
          )}

          {safeMessages.map((message) => {
            if (message.role === 'user') {
              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.16 }}
                  className="border-l border-[#333] pl-3 text-[#CFCFCF]"
                >
                  <div className="mb-1 text-[10px] uppercase tracking-[0.2em] text-[#8A8A8A]">USER INPUT</div>
                  <div>
                    <span className="text-[#F5F5F5]">C:\YOU&gt;</span> {message.text || '[IMAGE ATTACHED]'}
                  </div>
                  {message.imageMeta && (
                    <div className="mt-1 text-[11px] text-[#8A8A8A]">ATTACHMENT: {message.imageMeta.name}</div>
                  )}
                </motion.div>
              );
            }

            const lines = Array.isArray(message.displayLines) ? message.displayLines : [];
            const visibleCount = visibleLineCounts[message.id] ?? lines.length;
            const visibleLines = lines.slice(0, visibleCount);

            return (
              <div key={message.id} className="space-y-2">
                {visibleLines.map((line, index) => (
                  <motion.div
                    key={`${message.id}-${index}`}
                    variants={lineVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.18, ease: [0.2, 0.8, 0.2, 1] }}
                    className="terminal-line"
                  >
                    <span className="mr-2 text-[#8A8A8A]">&gt;</span>
                    <span>{line}</span>
                    {index === visibleLines.length - 1 && visibleCount < lines.length && <span className="terminal-cursor ml-1" />}
                  </motion.div>
                ))}
                {visibleCount >= lines.length && lines.length > 0 && message.id === safeMessages[safeMessages.length - 1]?.id && (
                  <span className="terminal-cursor ml-5" aria-hidden="true" />
                )}
              </div>
            );
          })}

          <AnimatePresence>
            {aiStatus.status === 'loading' && (
              <motion.div
                key="loading"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="flex items-center gap-3 text-[#8A8A8A]"
              >
                <Loader2 size={16} className="animate-spin text-[#F5F5F5]" />
                <span>GEMINI PIPE RATTLING<span className="terminal-dots" /></span>
              </motion.div>
            )}

            {aiStatus.status === 'error' && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="border border-[#FF4D4D] bg-[#160404] p-4 text-[#FF4D4D]"
                role="alert"
              >
                <div className="mb-3 flex items-center gap-2 font-semibold uppercase tracking-[0.18em]">
                  <AlertTriangle size={16} />
                  ERROR RETRY PANEL
                </div>
                <p className="mb-4 text-sm text-[#F5F5F5]">{aiStatus.error}</p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={onRetry}
                    className="min-h-11 border border-[#F5F5F5] px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                  >
                    Retry Last Message
                  </button>
                  <button
                    type="button"
                    onClick={onStartNewSession}
                    className="min-h-11 border border-[#333] px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                  >
                    Start New Session
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
