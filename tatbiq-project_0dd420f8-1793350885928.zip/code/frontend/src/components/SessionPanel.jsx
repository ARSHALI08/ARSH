import { useEffect, useState } from 'react';
import { Clock3, Edit3, Plus, RotateCcw, Trash2, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import appData from '../data/app-data.json';

const formatDate = (value) => {
  if (!value) return 'Unknown';
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  }).format(new Date(value));
};

const lastPreview = (session) => {
  const messages = Array.isArray(session.messages) ? session.messages : [];
  const last = messages[messages.length - 1];
  if (!last) return 'No messages yet.';
  if (last.role === 'assistant') return (last.displayLines || [last.rawText || 'Assistant output saved.'])[0] || 'Assistant output saved.';
  return last.text || 'Image attached.';
};

export default function SessionPanel({
  open,
  sessions,
  activeSessionId,
  onClose,
  onResume,
  onRename,
  onDelete,
  onStartNew
}) {
  const [renamingId, setRenamingId] = useState(null);
  const [sessionTitle, setSessionTitle] = useState('');
  const [titleError, setTitleError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);

  const safeSessions = Array.isArray(sessions) ? sessions : [];

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        if (deleteTarget) {
          setDeleteTarget(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, deleteTarget, onClose]);

  const startRename = (session) => {
    setRenamingId(session.id);
    setSessionTitle(session.title || '');
    setTitleError('');
  };

  const submitRename = async (event) => {
    event.preventDefault();
    const trimmed = sessionTitle.trim();

    if (!trimmed) {
      setTitleError('Title cannot be empty.');
      return;
    }

    if (trimmed.length > appData.limits.maxTitleLength) {
      setTitleError('Title must be 60 characters or less.');
      return;
    }

    await onRename(renamingId, trimmed);
    setRenamingId(null);
    setSessionTitle('');
    setTitleError('');
  };

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div className="fixed inset-0 z-40" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <button
              type="button"
              aria-label="Close history backdrop"
              className="absolute inset-0 cursor-default bg-black/55"
              onClick={onClose}
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
              className="absolute right-0 top-0 flex h-full w-full max-w-xl flex-col border-l border-[#2A2A2A] bg-[#030303] text-[#F5F5F5] shadow-[-30px_0_80px_rgba(0,0,0,0.45)]"
            >
              <header className="sticky top-0 z-10 flex items-center justify-between border-b border-[#2A2A2A] bg-[#0A0A0A] px-5 py-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.22em] text-[#8A8A8A]">Hybrid session storage</div>
                  <h2 className="font-heading text-lg font-semibold">History Panel</h2>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="inline-flex min-h-11 min-w-11 items-center justify-center border border-[#333] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                  aria-label="Close history"
                >
                  <X size={18} />
                </button>
              </header>

              <div className="flex-1 overflow-y-auto p-5">
                <button
                  type="button"
                  onClick={onStartNew}
                  className="mb-4 inline-flex min-h-11 w-full items-center justify-center gap-2 border border-[#F5F5F5] px-4 text-xs font-semibold uppercase tracking-[0.18em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                >
                  <Plus size={15} />
                  {appData.labels.startNew}
                </button>

                {safeSessions.length === 0 ? (
                  <div className="border border-dashed border-[#333] bg-[#050505] p-6 text-sm text-[#8A8A8A]">
                    No sessions saved yet. Start a conversation and the beef archive will appear here.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {safeSessions
                      .slice()
                      .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0))
                      .map((session) => (
                        <article
                          key={session.id}
                          className={`border bg-[#050505] p-4 transition duration-150 ${session.id === activeSessionId ? 'border-[#F5F5F5]' : 'border-[#2A2A2A] hover:border-[#F5F5F5]'}`}
                        >
                          {renamingId === session.id ? (
                            <form onSubmit={submitRename} className="space-y-3">
                              <input
                                value={sessionTitle}
                                onChange={(event) => setSessionTitle(event.target.value)}
                                autoFocus
                                className="min-h-11 w-full border border-[#333] bg-[#030303] px-3 text-sm text-[#F5F5F5] outline-none focus:border-[#F5F5F5]"
                                maxLength={appData.limits.maxTitleLength}
                              />
                              {titleError && <div className="text-xs text-[#FF4D4D]">{titleError}</div>}
                              <div className="flex gap-2">
                                <button
                                  type="submit"
                                  className="min-h-10 flex-1 border border-[#F5F5F5] text-xs uppercase tracking-[0.16em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                                >
                                  Save
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setRenamingId(null)}
                                  className="min-h-10 flex-1 border border-[#333] text-xs uppercase tracking-[0.16em] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                                >
                                  Cancel
                                </button>
                              </div>
                            </form>
                          ) : (
                            <>
                              <div className="mb-2 flex items-start justify-between gap-3">
                                <div>
                                  <h3 className="font-heading text-base font-semibold text-[#F5F5F5]">{session.title}</h3>
                                  <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-[#8A8A8A]">
                                    <span className="inline-flex items-center gap-1">
                                      <Clock3 size={12} />
                                      {formatDate(session.updatedAt)}
                                    </span>
                                    <span>{session.status}</span>
                                    <span>{session.progressScore || 0}/100</span>
                                  </div>
                                </div>
                              </div>

                              <p className="mb-4 line-clamp-2 text-xs leading-relaxed text-[#CFCFCF]">{lastPreview(session)}</p>

                              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                                <button
                                  type="button"
                                  onClick={() => onResume(session.id)}
                                  className="inline-flex min-h-10 items-center justify-center gap-1 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                                >
                                  <RotateCcw size={12} />
                                  Resume
                                </button>
                                <button
                                  type="button"
                                  onClick={() => startRename(session)}
                                  className="inline-flex min-h-10 items-center justify-center gap-1 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                                >
                                  <Edit3 size={12} />
                                  Rename
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeleteTarget(session)}
                                  className="inline-flex min-h-10 items-center justify-center gap-1 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] text-[#FF4D4D] transition duration-150 hover:border-[#FF4D4D] focus:outline-none focus:ring-2 focus:ring-[#FF4D4D]"
                                >
                                  <Trash2 size={12} />
                                  Delete
                                </button>
                              </div>
                            </>
                          )}
                        </article>
                      ))}
                  </div>
                )}
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deleteTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) setDeleteTarget(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.96, y: 8 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.96, y: 8 }}
              className="w-full max-w-md border border-[#FF4D4D] bg-[#030303] p-5 text-[#F5F5F5]"
            >
              <h3 className="font-heading text-lg font-semibold">Delete Forever?</h3>
              <p className="mt-2 text-sm text-[#CFCFCF]">
                This removes “{deleteTarget.title}” from storage. The terminal will not write a eulogy.
              </p>
              <div className="mt-5 flex gap-3">
                <button
                  type="button"
                  onClick={async () => {
                    await onDelete(deleteTarget.id);
                    setDeleteTarget(null);
                  }}
                  className="min-h-11 flex-1 border border-[#FF4D4D] px-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#FF4D4D] transition duration-150 hover:bg-[#FF4D4D] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#FF4D4D]"
                >
                  Delete Forever
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteTarget(null)}
                  className="min-h-11 flex-1 border border-[#333] px-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5F5F5] transition duration-150 hover:border-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5]"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
