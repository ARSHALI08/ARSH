import { useMemo, useState } from 'react';
import { CheckCircle2, CircleDashed, Clock, ImageUp, Play, RotateCcw, SendHorizontal, Square, TimerReset } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import appData from '../data/app-data.json';

const formatMs = (ms) => {
  const totalSeconds = Math.max(0, Math.floor((ms || 0) / 1000));
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
};

export default function TaskPanel({
  tasks,
  progressScore,
  timerState,
  disabled,
  onStartTimer,
  onPauseTimer,
  onResetTimer,
  onSubmitAttempt
}) {
  const [answers, setAnswers] = useState({});

  const safeTasks = Array.isArray(tasks) ? tasks : [];
  const activeTasks = safeTasks.filter((task) => task.status !== 'complete');
  const completedTasks = safeTasks.filter((task) => task.status === 'complete');

  const currentTask = useMemo(() => activeTasks[0] || safeTasks[0] || null, [activeTasks, safeTasks]);
  const scoreWidth = Math.min(100, Math.max(0, progressScore || 0));

  const timerElapsed = timerState?.elapsedMs || 0;
  const timerTarget = timerState?.targetDurationMs || currentTask?.timerMs || 0;
  const timerLabel = timerTarget > 0 ? `${formatMs(timerElapsed)} / ${formatMs(timerTarget)}` : formatMs(timerElapsed);

  const handleAttempt = async (task) => {
    const answer = answers[task.id] || '';
    await onSubmitAttempt(task.id, answer);
    setAnswers((current) => ({ ...current, [task.id]: '' }));
  };

  return (
    <aside className="flex w-full flex-col gap-4 lg:w-[320px]">
      <section className="border border-[#2A2A2A] bg-[#0A0A0A] p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.18em] text-[#F5F5F5]">Progress</h2>
          <span className="border border-[#333] px-2 py-1 font-body text-xs text-[#CFCFCF]">{progressScore || 0}/100</span>
        </div>
        <div className="h-2 border border-[#333] bg-[#030303]">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${scoreWidth}%` }}
            transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
            className="h-full bg-[#F5F5F5]"
          />
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-[#8A8A8A]">
          <div className="border border-[#2A2A2A] bg-[#050505] p-2">
            <div className="text-[#F5F5F5]">{activeTasks.length}</div>
            <div>ACTIVE</div>
          </div>
          <div className="border border-[#2A2A2A] bg-[#050505] p-2">
            <div className="text-[#F5F5F5]">{completedTasks.length}</div>
            <div>DONE</div>
          </div>
        </div>
      </section>

      <section className="border border-[#2A2A2A] bg-[#0A0A0A]">
        <div className="border-b border-[#2A2A2A] px-4 py-3">
          <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.18em] text-[#F5F5F5]">Task Stack</h2>
        </div>

        <div className="max-h-[52vh] overflow-y-auto p-3">
          {safeTasks.length === 0 ? (
            <div className="border border-dashed border-[#333] bg-[#050505] p-4 text-sm text-[#8A8A8A]">
              <CircleDashed size={20} className="mb-3 text-[#CFCFCF]" />
              No tasks yet. The AI is waiting to turn your problem into homework with teeth.
            </div>
          ) : (
            <div className="space-y-3">
              <AnimatePresence>
                {safeTasks.map((task) => {
                  const statusLabel = appData.taskStatusLabels[task.status] || `[${task.status || 'ACTIVE'}]`;
                  const isCurrent = currentTask?.id === task.id;
                  const taskTimerActive = timerState?.taskId === task.id;

                  return (
                    <motion.article
                      layout
                      key={task.id}
                      initial={{ opacity: 0, x: 16 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 16 }}
                      transition={{ duration: 0.22 }}
                      className={`border bg-[#050505] p-3 transition duration-150 ${isCurrent ? 'border-[#F5F5F5]' : 'border-[#2A2A2A] hover:border-[#555]'}`}
                    >
                      <div className="mb-2 flex items-start justify-between gap-3">
                        <div>
                          <div className="text-[10px] uppercase tracking-[0.18em] text-[#8A8A8A]">{statusLabel}</div>
                          <h3 className="mt-1 font-heading text-sm font-semibold text-[#F5F5F5]">{task.title}</h3>
                        </div>
                        {task.status === 'complete' ? <CheckCircle2 size={18} className="text-[#F5F5F5]" /> : <CircleDashed size={18} className="text-[#8A8A8A]" />}
                      </div>

                      <p className="mb-3 text-xs leading-relaxed text-[#CFCFCF]">{task.description}</p>

                      <div className="mb-3 flex flex-wrap gap-2 text-[10px] uppercase tracking-[0.14em] text-[#8A8A8A]">
                        <span className="border border-[#333] px-2 py-1">DIF {task.difficulty || 1}</span>
                        <span className="border border-[#333] px-2 py-1">+{task.scoreValue || 0} SCORE</span>
                        {task.requiresImage && (
                          <span className="inline-flex items-center gap-1 border border-[#333] px-2 py-1">
                            <ImageUp size={12} />
                            IMAGE PROOF
                          </span>
                        )}
                      </div>

                      {taskTimerActive && (
                        <div className="mb-3 border border-[#333] bg-[#030303] p-2 text-xs text-[#CFCFCF]">
                          <div className="mb-2 flex items-center gap-2">
                            <Clock size={14} />
                            <span>{timerLabel}</span>
                          </div>
                          <div className="flex gap-2">
                            {timerState.status === 'running' ? (
                              <button
                                type="button"
                                disabled={disabled}
                                onClick={onPauseTimer}
                                className="inline-flex min-h-10 flex-1 items-center justify-center gap-2 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                              >
                                <Square size={12} />
                                {appData.labels.pauseTimer}
                              </button>
                            ) : (
                              <button
                                type="button"
                                disabled={disabled}
                                onClick={() => onStartTimer(task.id)}
                                className="inline-flex min-h-10 flex-1 items-center justify-center gap-2 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                              >
                                <Play size={12} />
                                Resume
                              </button>
                            )}
                            <button
                              type="button"
                              disabled={disabled}
                              onClick={onResetTimer}
                              className="inline-flex min-h-10 flex-1 items-center justify-center gap-2 border border-[#333] px-2 text-[10px] uppercase tracking-[0.14em] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                            >
                              <RotateCcw size={12} />
                              {appData.labels.resetTimer}
                            </button>
                          </div>
                        </div>
                      )}

                      {!taskTimerActive && task.status !== 'complete' && (
                        <button
                          type="button"
                          disabled={disabled}
                          onClick={() => onStartTimer(task.id)}
                          className="mb-3 inline-flex min-h-10 w-full items-center justify-center gap-2 border border-[#333] px-3 text-[10px] uppercase tracking-[0.16em] text-[#CFCFCF] transition duration-150 hover:border-[#F5F5F5] hover:text-[#F5F5F5] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                        >
                          <TimerReset size={13} />
                          {appData.labels.startTimer}
                        </button>
                      )}

                      {task.status !== 'complete' && (
                        <div className="space-y-2">
                          <textarea
                            value={answers[task.id] || ''}
                            onChange={(event) => setAnswers((current) => ({ ...current, [task.id]: event.target.value }))}
                            disabled={disabled}
                            rows={2}
                            placeholder="Submit the attempt. No poetry unless useful."
                            className="w-full resize-none border border-[#333] bg-[#030303] p-2 text-xs text-[#F5F5F5] outline-none placeholder:text-[#666] focus:border-[#F5F5F5] disabled:opacity-40"
                          />
                          <button
                            type="button"
                            disabled={disabled}
                            onClick={() => handleAttempt(task)}
                            className="inline-flex min-h-10 w-full items-center justify-center gap-2 border border-[#F5F5F5] px-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-[#F5F5F5] transition duration-150 hover:bg-[#F5F5F5] hover:text-[#030303] focus:outline-none focus:ring-2 focus:ring-[#F5F5F5] disabled:opacity-40"
                          >
                            <SendHorizontal size={13} />
                            {appData.labels.markAttempted}
                          </button>
                        </div>
                      )}
                    </motion.article>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </section>
    </aside>
  );
}
