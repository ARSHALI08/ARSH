import { createContext, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import Layout from './components/Layout.jsx';
import AiAssistant from './components/AiAssistant.jsx';
import { useSupabase } from './hooks/useSupabase.js';
import appData from './data/app-data.json';

export const AppContext = createContext(null);

const nowIso = () => new Date().toISOString();
const id = (prefix) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const createSession = () => ({
  id: id('session'),
  title: 'Untitled beef',
  createdAt: nowIso(),
  updatedAt: nowIso(),
  status: 'active',
  uiMode: 'normal',
  aiAlias: appData.defaultAlias,
  blockCount: 0,
  progressScore: 0,
  messages: [],
  tasks: [],
  timerState: {
    taskId: null,
    status: 'idle',
    elapsedMs: 0,
    targetDurationMs: 0,
    startedAt: null
  },
  blockEvents: [],
  uploads: []
});

const titleFromMessage = (text) => {
  const trimmed = (text || '').trim();
  if (!trimmed) return 'Image proof session';
  return trimmed.length > 46 ? `${trimmed.slice(0, 43)}...` : trimmed;
};

const splitTerminalLines = (rawText) => {
  const text = String(rawText || '').trim();
  if (!text) return ['NO OUTPUT. Disturbing.'];
  const explicit = text
    .split(/\n+/)
    .map((line) => line.replace(/^[-*>#\s]+/, '').trim())
    .filter(Boolean);

  if (explicit.length > 1) return explicit.slice(0, 14);

  return text
    .split(/(?<=[.!?])\s+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 14);
};

const stripJsonFence = (value) =>
  String(value || '')
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();

const parseGeminiPayload = (rawText) => {
  const clean = stripJsonFence(rawText);
  try {
    const parsed = JSON.parse(clean);
    return {
      rawText,
      displayLines: Array.isArray(parsed.displayLines) && parsed.displayLines.length > 0 ? parsed.displayLines : splitTerminalLines(rawText),
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
      evaluation: parsed.evaluation || null,
      progressDelta: parsed.progressDelta || null,
      tone: parsed.tone || 'teasing',
      requiresImage: Boolean(parsed.requiresImage),
      timerSuggestion: parsed.timerSuggestion || null
    };
  } catch {
    return {
      rawText,
      displayLines: splitTerminalLines(rawText),
      tasks: [],
      evaluation: null,
      progressDelta: null,
      tone: 'teasing',
      requiresImage: false,
      timerSuggestion: null
    };
  }
};

const normalizeTask = (task) => ({
  id: task.id || id('task'),
  title: task.title || 'Unnamed task, somehow',
  description: task.description || 'Do the thing clearly enough to evaluate.',
  status: task.status || 'active',
  difficulty: Number(task.difficulty || 1),
  requiresImage: Boolean(task.requiresImage),
  timerMs: Number(task.timerMs || task.timerSuggestion || 0),
  scoreValue: Number(task.scoreValue || 8),
  attempts: Array.isArray(task.attempts) ? task.attempts : []
});

const buildPrompt = ({ session, messageText, imageAttached, intent, task, answer }) => {
  const schema = JSON.stringify(appData.responseSchemaHint, null, 2);
  const history = (session.messages || []).slice(-12).map((message) => ({
    role: message.role,
    text: message.role === 'assistant' ? (message.displayLines || []).join('\n') : message.text,
    imageMeta: message.imageMeta || null
  }));

  return [
    appData.systemPromptFragments.join('\n'),
    '',
    'Return ONLY valid JSON matching this shape when possible:',
    schema,
    '',
    'CURRENT SESSION CONTEXT:',
    JSON.stringify(
      {
        intent,
        alias: session.aiAlias,
        blockCount: session.blockCount,
        progressScore: session.progressScore,
        activeTasks: session.tasks,
        timerState: session.timerState,
        recentHistory: history,
        imageAttached,
        taskUnderEvaluation: task || null,
        attemptAnswer: answer || null
      },
      null,
      2
    ),
    '',
    'USER MESSAGE:',
    messageText || '[No text supplied. Image may be attached.]'
  ].join('\n');
};

const extractGeminiText = (data) => {
  const parts = data?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  return parts.map((part) => part.text || '').join('\n').trim();
};

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

export default function App() {
  const {
    getSessions,
    saveSessions,
    getActiveSessionId,
    setActiveSessionId,
    deleteSessionById,
    getPreferences,
    setPreferences
  } = useSupabase();

  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionIdState] = useState(null);
  const [uiMode, setUiMode] = useState('normal');
  const [visibleLineCounts, setVisibleLineCounts] = useState({});
  const [attachedImage, setAttachedImage] = useState(null);
  const [aiStatus, setAiStatus] = useState({ status: 'idle', error: '', retryPayload: null });
  const [historyOpen, setHistoryOpen] = useState(false);
  const [flashActive, setFlashActive] = useState(false);
  const [aliasGlitch, setAliasGlitch] = useState(false);

  const revealTimersRef = useRef([]);
  const timerIntervalRef = useRef(null);

  const activeSession = useMemo(
    () => sessions.find((session) => session.id === activeSessionId) || sessions[0] || null,
    [sessions, activeSessionId]
  );

  const persistSessions = useCallback(
    async (nextSessions, options = {}) => {
      setSessions(nextSessions);
      await saveSessions(nextSessions);
      if (options.toastMessage) toast.success(options.toastMessage);
    },
    [saveSessions]
  );

  const updateActiveSession = useCallback(
    async (updater, options = {}) => {
      let updatedSession = null;
      const nextSessions = sessions.map((session) => {
        if (session.id !== activeSessionId) return session;
        updatedSession = {
          ...updater(session),
          updatedAt: nowIso()
        };
        return updatedSession;
      });
      await persistSessions(nextSessions, options);
      return updatedSession;
    },
    [activeSessionId, persistSessions, sessions]
  );

  const revealMessageLines = useCallback((messageId, lines) => {
    revealTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    revealTimersRef.current = [];

    setAiStatus((current) => ({ ...current, status: 'revealing', error: '' }));
    setVisibleLineCounts((current) => ({ ...current, [messageId]: 0 }));

    let accumulatedDelay = 120;
    const safeLines = Array.isArray(lines) ? lines : [];

    safeLines.forEach((line, index) => {
      const punctuationPause = /[!?]$/.test(line) ? 720 : /[.]$/.test(line) ? 420 : 280;
      const lengthPause = Math.min(360, Math.max(120, String(line).length * 12));
      accumulatedDelay += punctuationPause + lengthPause;

      const timer = window.setTimeout(() => {
        setVisibleLineCounts((current) => ({ ...current, [messageId]: index + 1 }));
        if (index === safeLines.length - 1) {
          setAiStatus((current) => ({ ...current, status: 'idle', error: '' }));
        }
      }, accumulatedDelay);

      revealTimersRef.current.push(timer);
    });

    if (safeLines.length === 0) {
      setAiStatus((current) => ({ ...current, status: 'idle', error: '' }));
    }
  }, []);

  const callGemini = useCallback(async ({ session, messageText, image, intent = 'conversation', task = null, answer = null }) => {
    if (!apiKey) {
      throw new Error(appData.errors.noApiKey);
    }

    const promptText = buildPrompt({
      session,
      messageText,
      imageAttached: Boolean(image),
      intent,
      task,
      answer
    });

    const parts = [{ text: promptText }];
    if (image?.base64 && image?.type) {
      parts.push({
        inline_data: {
          mime_type: image.type,
          data: image.base64
        }
      });
    }

    const response = await fetch(`${appData.gemini.endpoint}?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: appData.systemPromptFragments.join('\n') }]
        },
        contents: [
          {
            role: 'user',
            parts
          }
        ],
        generationConfig: {
          temperature: 0.9,
          topP: 0.92,
          maxOutputTokens: 1600,
          responseMimeType: 'application/json'
        }
      })
    });

    if (!response.ok) {
      throw new Error(appData.errors.generic);
    }

    const data = await response.json();
    const text = extractGeminiText(data);

    if (!text) {
      throw new Error(appData.errors.generic);
    }

    return parseGeminiPayload(text);
  }, []);

  const applyAiPayloadToSession = useCallback((session, payload, assistantMessage) => {
    const incomingTasks = Array.isArray(payload.tasks) ? payload.tasks.map(normalizeTask) : [];
    const taskMap = new Map((session.tasks || []).map((task) => [task.id, task]));

    incomingTasks.forEach((task) => {
      const existing = taskMap.get(task.id);
      taskMap.set(task.id, existing ? { ...existing, ...task, attempts: existing.attempts || task.attempts || [] } : task);
    });

    let nextTasks = Array.from(taskMap.values());

    if (payload.evaluation?.taskId) {
      nextTasks = nextTasks.map((task) => {
        if (task.id !== payload.evaluation.taskId) return task;
        return {
          ...task,
          status: payload.evaluation.status || task.status,
          attempts: [
            ...(task.attempts || []),
            {
              id: id('attempt'),
              feedback: payload.evaluation.feedback || '',
              nextHint: payload.evaluation.nextHint || '',
              status: payload.evaluation.status || 'partial',
              createdAt: nowIso()
            }
          ]
        };
      });
    }

    const progressDelta = Number(payload.progressDelta?.value || 0);
    const nextProgress = Math.min(100, Math.max(0, Number(session.progressScore || 0) + progressDelta));

    let nextTimerState = session.timerState;
    if (payload.timerSuggestion?.taskId && payload.timerSuggestion?.durationMs) {
      nextTimerState = {
        taskId: payload.timerSuggestion.taskId,
        status: 'paused',
        elapsedMs: 0,
        targetDurationMs: Number(payload.timerSuggestion.durationMs),
        startedAt: null
      };
    }

    return {
      ...session,
      uiMode: 'terminal',
      progressScore: nextProgress,
      tasks: nextTasks,
      timerState: nextTimerState,
      messages: [...(session.messages || []), assistantMessage]
    };
  }, []);

  const executeAiTurn = useCallback(
    async ({ baseSession, messageText, image, intent = 'conversation', task = null, answer = null, userMessage = null }) => {
      const retryPayload = { messageText, image, intent, task, answer };
      setAiStatus({ status: 'loading', error: '', retryPayload });

      try {
        const payload = await callGemini({ session: baseSession, messageText, image, intent, task, answer });
        const assistantMessage = {
          id: id('msg'),
          role: 'assistant',
          rawText: payload.rawText,
          displayLines: payload.displayLines,
          createdAt: nowIso(),
          model: 'gemini'
        };

        const nextSessions = sessions.map((session) => {
          if (session.id !== baseSession.id) return session;
          const withUser = userMessage ? { ...session, messages: [...(session.messages || []), userMessage] } : session;
          return {
            ...applyAiPayloadToSession(withUser, payload, assistantMessage),
            updatedAt: nowIso()
          };
        });

        await persistSessions(nextSessions);
        setAttachedImage(null);
        revealMessageLines(assistantMessage.id, assistantMessage.displayLines);
        toast.success('Saved!');
      } catch (error) {
        const errorText = error instanceof Error ? error.message : appData.errors.generic;
        setAiStatus({ status: 'error', error: errorText, retryPayload });
        toast.error('Save failed: ' + errorText);

        if (userMessage) {
          const nextSessions = sessions.map((session) =>
            session.id === baseSession.id
              ? {
                  ...session,
                  uiMode: 'terminal',
                  messages: [...(session.messages || []), userMessage],
                  updatedAt: nowIso()
                }
              : session
          );
          await persistSessions(nextSessions);
        }
      }
    },
    [applyAiPayloadToSession, callGemini, persistSessions, revealMessageLines, sessions]
  );

  const handleSend = useCallback(
    async (messageText) => {
      const text = String(messageText || '').trim();

      if (!text && !attachedImage) {
        toast.error(appData.errors.emptyMessage);
        return;
      }

      let session = activeSession || createSession();
      const isNew = !activeSession;
      const firstMessage = (session.messages || []).length === 0;
      const imageMeta = attachedImage
        ? {
            name: attachedImage.name,
            type: attachedImage.type,
            size: attachedImage.size,
            createdAt: attachedImage.createdAt
          }
        : null;

      const userMessage = {
        id: id('msg'),
        role: 'user',
        text,
        imageMeta,
        createdAt: nowIso()
      };

      if (firstMessage) {
        session = {
          ...session,
          title: titleFromMessage(text),
          uiMode: 'loadingReveal'
        };
      }

      const nextSessions = isNew
        ? [session, ...sessions]
        : sessions.map((item) => (item.id === session.id ? { ...session, updatedAt: nowIso() } : item));

      setSessions(nextSessions);
      await saveSessions(nextSessions);
      setActiveSessionIdState(session.id);
      await setActiveSessionId(session.id);

      if (firstMessage) {
        setUiMode('loadingReveal');
        await sleep(1050);
        setFlashActive(true);
        await sleep(120);
        setFlashActive(false);
        setUiMode('terminal');
        session = { ...session, uiMode: 'terminal' };
      } else {
        setUiMode('terminal');
      }

      await executeAiTurn({
        baseSession: session,
        messageText: text,
        image: attachedImage,
        intent: 'conversation',
        userMessage
      });
    },
    [activeSession, attachedImage, executeAiTurn, saveSessions, sessions, setActiveSessionId]
  );

  const handleAttachImage = useCallback((image) => {
    setAttachedImage(image);
    toast.success('Image attached.');
  }, []);

  const handleRemoveImage = useCallback(() => {
    setAttachedImage(null);
    toast.success('Image removed.');
  }, []);

  const handleRetry = useCallback(async () => {
    if (!activeSession || !aiStatus.retryPayload) {
      toast.error('Nothing to retry. Suspiciously peaceful.');
      return;
    }

    await executeAiTurn({
      baseSession: activeSession,
      ...aiStatus.retryPayload,
      userMessage: null
    });
  }, [activeSession, aiStatus.retryPayload, executeAiTurn]);

  const handleEditLastMessage = useCallback(() => {
    setAiStatus((current) => ({ ...current, status: 'idle', error: '' }));
    toast.success('Edit the composer and send again.');
  }, []);

  const handleStartNewSession = useCallback(async () => {
    const fresh = createSession();
    const nextSessions = [fresh, ...sessions];
    setVisibleLineCounts({});
    setAttachedImage(null);
    setAiStatus({ status: 'idle', error: '', retryPayload: null });
    setUiMode('normal');
    setHistoryOpen(false);
    setActiveSessionIdState(fresh.id);
    await persistSessions(nextSessions, { toastMessage: 'New session ready.' });
    await setActiveSessionId(fresh.id);
  }, [persistSessions, sessions, setActiveSessionId]);

  const handleResumeSession = useCallback(
    async (sessionId) => {
      const session = sessions.find((item) => item.id === sessionId);
      if (!session) {
        toast.error('Session not found.');
        return;
      }

      setActiveSessionIdState(sessionId);
      await setActiveSessionId(sessionId);
      setUiMode(session.status === 'ended' ? 'ended' : session.uiMode || 'terminal');
      setHistoryOpen(false);
      const counts = {};
      (session.messages || []).forEach((message) => {
        if (message.role === 'assistant') counts[message.id] = (message.displayLines || []).length;
      });
      setVisibleLineCounts(counts);
      toast.success('Session resumed.');
    },
    [sessions, setActiveSessionId]
  );

  const handleRenameSession = useCallback(
    async (sessionId, title) => {
      const nextSessions = sessions.map((session) => (session.id === sessionId ? { ...session, title, updatedAt: nowIso() } : session));
      await persistSessions(nextSessions, { toastMessage: 'Session renamed.' });
    },
    [persistSessions, sessions]
  );

  const handleDeleteSession = useCallback(
    async (sessionId) => {
      const nextSessions = await deleteSessionById(sessionId);
      setSessions(nextSessions);
      if (activeSessionId === sessionId) {
        const nextActive = nextSessions[0] || createSession();
        const finalSessions = nextSessions.length > 0 ? nextSessions : [nextActive];
        setSessions(finalSessions);
        await saveSessions(finalSessions);
        setActiveSessionIdState(nextActive.id);
        await setActiveSessionId(nextActive.id);
        setUiMode(nextActive.uiMode || 'normal');
      }
      toast.success('Session deleted.');
    },
    [activeSessionId, deleteSessionById, saveSessions, setActiveSessionId]
  );

  const handleStartTimer = useCallback(
    async (taskId) => {
      if (!activeSession) return;
      const task = (activeSession.tasks || []).find((item) => item.id === taskId);
      if (!task) {
        toast.error(appData.errors.noTask);
        return;
      }

      await updateActiveSession(
        (session) => ({
          ...session,
          timerState: {
            taskId,
            status: 'running',
            elapsedMs: session.timerState?.taskId === taskId ? session.timerState.elapsedMs || 0 : 0,
            targetDurationMs: task.timerMs || session.timerState?.targetDurationMs || 0,
            startedAt: Date.now()
          }
        }),
        { toastMessage: 'Timer started.' }
      );
    },
    [activeSession, updateActiveSession]
  );

  const handlePauseTimer = useCallback(async () => {
    if (!activeSession?.timerState?.taskId) {
      toast.error(appData.errors.noTask);
      return;
    }

    const elapsedSinceStart = activeSession.timerState.startedAt ? Date.now() - Number(activeSession.timerState.startedAt) : 0;
    await updateActiveSession(
      (session) => ({
        ...session,
        timerState: {
          ...session.timerState,
          status: 'paused',
          elapsedMs: Number(session.timerState.elapsedMs || 0) + elapsedSinceStart,
          startedAt: null
        }
      }),
      { toastMessage: 'Timer paused.' }
    );
  }, [activeSession, updateActiveSession]);

  const handleResetTimer = useCallback(async () => {
    if (!activeSession?.timerState?.taskId) {
      toast.error(appData.errors.noTask);
      return;
    }

    const shouldReset = Number(activeSession.timerState.elapsedMs || 0) === 0 || window.confirm('Reset this timer?');
    if (!shouldReset) return;

    await updateActiveSession(
      (session) => ({
        ...session,
        timerState: {
          ...session.timerState,
          status: 'paused',
          elapsedMs: 0,
          startedAt: null
        }
      }),
      { toastMessage: 'Timer reset.' }
    );
  }, [activeSession, updateActiveSession]);

  const handleSubmitAttempt = useCallback(
    async (taskId, answer) => {
      if (!activeSession) return;
      const task = (activeSession.tasks || []).find((item) => item.id === taskId);

      if (!task) {
        toast.error(appData.errors.noTask);
        return;
      }

      if (!String(answer || '').trim() && !attachedImage) {
        toast.error('Attempt needs text or image proof. The task cannot grade vibes.');
        return;
      }

      const userMessage = {
        id: id('msg'),
        role: 'user',
        text: `[TASK ATTEMPT: ${task.title}] ${answer || ''}`.trim(),
        imageMeta: attachedImage
          ? {
              name: attachedImage.name,
              type: attachedImage.type,
              size: attachedImage.size,
              createdAt: attachedImage.createdAt
            }
          : null,
        createdAt: nowIso()
      };

      await executeAiTurn({
        baseSession: activeSession,
        messageText: userMessage.text,
        image: attachedImage,
        intent: 'task_evaluation',
        task,
        answer,
        userMessage
      });
    },
    [activeSession, attachedImage, executeAiTurn]
  );

  const handleOpenBlock = useCallback(() => {
    if (!activeSession || activeSession.status === 'ended') return;
    setUiMode('blocked');
  }, [activeSession]);

  const pickAlias = useCallback((currentAlias, blockCount) => {
    const aliases = appData.aliasSeeds.filter((alias) => alias !== currentAlias);
    return aliases[blockCount % aliases.length] || appData.defaultAlias;
  }, []);

  const handleLetBack = useCallback(async () => {
    if (!activeSession || activeSession.status === 'ended') {
      toast.error('Session is already ended.');
      return;
    }

    const previousAlias = activeSession.aiAlias;
    const nextAlias = pickAlias(previousAlias, activeSession.blockCount + 1);

    const updatedSession = await updateActiveSession(
      (session) => ({
        ...session,
        uiMode: 'terminal',
        aiAlias: nextAlias,
        blockCount: Number(session.blockCount || 0) + 1,
        blockEvents: [
          ...(session.blockEvents || []),
          {
            id: id('block'),
            previousAlias,
            nextAlias,
            createdAt: nowIso()
          }
        ]
      }),
      { toastMessage: 'It came back. Obviously.' }
    );

    setUiMode('terminal');
    setAliasGlitch(true);
    window.setTimeout(() => setAliasGlitch(false), 560);

    if (updatedSession) {
      await executeAiTurn({
        baseSession: updatedSession,
        messageText: `The user clicked BLOCK IT. You returned as ${nextAlias}. Reference the incident briefly and continue the unfinished work.`,
        image: null,
        intent: 'block_reentry',
        userMessage: null
      });
    }
  }, [activeSession, executeAiTurn, pickAlias, updateActiveSession]);

  const handleEndSession = useCallback(async () => {
    if (!activeSession) return;

    const finalMessage = {
      id: id('msg'),
      role: 'assistant',
      rawText: 'SESSION TERMINATED BY USER. THE BEEF HAS BEEN ENDED.',
      displayLines: ['SESSION TERMINATED BY USER.', 'THE BEEF HAS BEEN ENDED.', 'START A NEW SESSION IF YOU MISS THE NOISE.'],
      createdAt: nowIso(),
      model: 'system'
    };

    await updateActiveSession(
      (session) => ({
        ...session,
        status: 'ended',
        uiMode: 'ended',
        messages: [...(session.messages || []), finalMessage]
      }),
      { toastMessage: 'Session ended.' }
    );

    setUiMode('ended');
    revealMessageLines(finalMessage.id, finalMessage.displayLines);
  }, [activeSession, revealMessageLines, updateActiveSession]);

  useEffect(() => {
    const loadInitial = async () => {
      const savedSessions = await getSessions();
      const activeId = await getActiveSessionId();
      const preferences = await getPreferences();

      if (preferences?.lastOpenedHistoryPanel) setHistoryOpen(true);

      if (Array.isArray(savedSessions) && savedSessions.length > 0) {
        const preferred = savedSessions.find((session) => session.id === activeId) || savedSessions[0];
        setSessions(savedSessions);
        setActiveSessionIdState(preferred.id);
        setUiMode(preferred.status === 'ended' ? 'ended' : preferred.uiMode || 'normal');

        const counts = {};
        (preferred.messages || []).forEach((message) => {
          if (message.role === 'assistant') counts[message.id] = (message.displayLines || []).length;
        });
        setVisibleLineCounts(counts);
      } else {
        const fresh = createSession();
        setSessions([fresh]);
        setActiveSessionIdState(fresh.id);
        await saveSessions([fresh]);
        await setActiveSessionId(fresh.id);
      }
    };

    loadInitial();
  }, [getActiveSessionId, getPreferences, getSessions, saveSessions, setActiveSessionId]);

  useEffect(() => {
    setPreferences({ lastOpenedHistoryPanel: historyOpen });
  }, [historyOpen, setPreferences]);

  useEffect(() => {
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);

    if (activeSession?.timerState?.status === 'running') {
      timerIntervalRef.current = window.setInterval(() => {
        setSessions((currentSessions) =>
          currentSessions.map((session) => {
            if (session.id !== activeSession.id || session.timerState?.status !== 'running') return session;
            return {
              ...session,
              timerState: {
                ...session.timerState,
                elapsedMs: Number(session.timerState.elapsedMs || 0) + 1000,
                startedAt: Date.now()
              }
            };
          })
        );
      }, 1000);
    }

    return () => {
      if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    };
  }, [activeSession?.id, activeSession?.timerState?.status]);

  useEffect(() => {
    return () => {
      revealTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    };
  }, []);

  const contextValue = useMemo(
    () => ({
      sessions,
      activeSession,
      uiMode,
      aiStatus
    }),
    [activeSession, aiStatus, sessions, uiMode]
  );

  return (
    <AppContext.Provider value={contextValue}>
      <Layout
        activeSession={activeSession}
        sessions={sessions || []}
        uiMode={uiMode}
        messages={activeSession?.messages || []}
        visibleLineCounts={visibleLineCounts}
        tasks={activeSession?.tasks || []}
        progressScore={activeSession?.progressScore || 0}
        timerState={activeSession?.timerState}
        attachedImage={attachedImage}
        aiStatus={aiStatus}
        historyOpen={historyOpen}
        flashActive={flashActive}
        aliasGlitch={aliasGlitch}
        onOpenHistory={() => setHistoryOpen(true)}
        onCloseHistory={() => setHistoryOpen(false)}
        onStartNewSession={handleStartNewSession}
        onResumeSession={handleResumeSession}
        onRenameSession={handleRenameSession}
        onDeleteSession={handleDeleteSession}
        onSend={handleSend}
        onAttachImage={handleAttachImage}
        onRemoveImage={handleRemoveImage}
        onRetry={handleRetry}
        onEditLastMessage={handleEditLastMessage}
        onStartTimer={handleStartTimer}
        onPauseTimer={handlePauseTimer}
        onResetTimer={handleResetTimer}
        onSubmitAttempt={handleSubmitAttempt}
        onOpenBlock={handleOpenBlock}
        onLetBack={handleLetBack}
        onEndSession={handleEndSession}
      />
      <AiAssistant />
      <Toaster
        position="bottom-left"
        toastOptions={{
          style: {
            border: '1px solid #2A2A2A',
            borderRadius: 0,
            background: '#0A0A0A',
            color: '#F5F5F5',
            fontFamily: 'var(--font-body)'
          }
        }}
      />
    </AppContext.Provider>
  );
}
