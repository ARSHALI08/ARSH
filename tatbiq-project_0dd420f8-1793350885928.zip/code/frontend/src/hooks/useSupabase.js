import { useMemo } from 'react';
import toast from 'react-hot-toast';
import supabase, { isSupabaseConfigured } from '../lib/supabase.js';
import appData from '../data/app-data.json';

const { storageKeys } = appData;

const safeParse = (value, fallback) => {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
};

const readStorage = (key, fallback) => {
  if (typeof window === 'undefined') return fallback;
  return safeParse(window.localStorage.getItem(key), fallback);
};

const writeStorage = (key, value) => {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(value));
};

const getErrorMessage = (error) => (error instanceof Error ? error.message : 'Unknown Supabase error');

export const toSnakeCase = (value) => {
  if (Array.isArray(value)) return value.map(toSnakeCase);
  if (!value || typeof value !== 'object') return value;

  return Object.entries(value).reduce((next, [key, item]) => {
    const snakeKey = key.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
    next[snakeKey] = toSnakeCase(item);
    return next;
  }, {});
};

export const toCamelCase = (value) => {
  if (Array.isArray(value)) return value.map(toCamelCase);
  if (!value || typeof value !== 'object') return value;

  return Object.entries(value).reduce((next, [key, item]) => {
    const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
    next[camelKey] = toCamelCase(item);
    return next;
  }, {});
};

const defaultTimerState = {
  taskId: null,
  status: 'idle',
  elapsedMs: 0,
  targetDurationMs: 0,
  startedAt: null
};

const defaultPreferences = {
  reducedMotion: false,
  lastOpenedHistoryPanel: false
};

const sessionToRow = (session) => {
  const snake = toSnakeCase(session || {});
  const timestamp = new Date().toISOString();

  return {
    session_id: session?.id || snake.session_id,
    title: snake.title || 'Untitled beef',
    created_at: snake.created_at || timestamp,
    updated_at: snake.updated_at || timestamp,
    status: snake.status || 'active',
    ui_mode: snake.ui_mode || 'normal',
    ai_alias: snake.ai_alias || appData.defaultAlias,
    block_count: Number(snake.block_count || 0),
    progress_score: Number(snake.progress_score || 0),
    messages: Array.isArray(snake.messages) ? snake.messages : [],
    tasks: Array.isArray(snake.tasks) ? snake.tasks : [],
    timer_state: snake.timer_state || toSnakeCase(defaultTimerState),
    block_events: Array.isArray(snake.block_events) ? snake.block_events : [],
    uploads: Array.isArray(snake.uploads) ? snake.uploads : []
  };
};

const rowToSession = (row) => {
  const data = toCamelCase(row || {});
  const timestamp = new Date().toISOString();

  return {
    id: row?.session_id || data.sessionId || data.id,
    title: data.title || 'Untitled beef',
    createdAt: data.createdAt || timestamp,
    updatedAt: data.updatedAt || data.createdAt || timestamp,
    status: data.status || 'active',
    uiMode: data.uiMode || 'normal',
    aiAlias: data.aiAlias || appData.defaultAlias,
    blockCount: Number(data.blockCount || 0),
    progressScore: Number(data.progressScore || 0),
    messages: Array.isArray(data.messages) ? data.messages : [],
    tasks: Array.isArray(data.tasks) ? data.tasks : [],
    timerState: data.timerState || defaultTimerState,
    blockEvents: Array.isArray(data.blockEvents) ? data.blockEvents : [],
    uploads: Array.isArray(data.uploads) ? data.uploads : []
  };
};

export const getSessions = async () => {
  const fallback = readStorage(storageKeys.sessions, []);

  if (!isSupabaseConfigured()) return fallback;

  try {
    const { data, error } = await supabase
      .from('sessions')
      .select('*')
      .order('updated_at', { ascending: false });

    if (error) throw error;

    const sessions = Array.isArray(data) ? data.map(rowToSession) : [];
    writeStorage(storageKeys.sessions, sessions);
    return sessions;
  } catch (error) {
    toast.error('Error loading sessions: ' + getErrorMessage(error));
    return fallback;
  }
};

export const saveSessions = async (sessions) => {
  const nextSessions = Array.isArray(sessions) ? sessions : [];
  writeStorage(storageKeys.sessions, nextSessions);

  if (!isSupabaseConfigured()) return nextSessions;

  try {
    const rows = nextSessions.map(sessionToRow).filter((row) => row.session_id);

    if (rows.length > 0) {
      const { error } = await supabase
        .from('sessions')
        .upsert(rows, { onConflict: 'session_id' });

      if (error) throw error;
    }

    toast.success('Data saved successfully!');
    return nextSessions;
  } catch (error) {
    toast.error('Error saving sessions: ' + getErrorMessage(error));
    writeStorage(storageKeys.sessions, nextSessions);
    return nextSessions;
  }
};

export const getActiveSessionId = async () => {
  const fallback = typeof window === 'undefined' ? null : window.localStorage.getItem(storageKeys.activeSessionId);

  if (!isSupabaseConfigured()) return fallback;

  try {
    const { data, error } = await supabase
      .from('active_sessions')
      .select('active_session_id')
      .eq('user_key', 'default')
      .limit(1);

    if (error) throw error;

    const activeSessionId = Array.isArray(data) ? data[0]?.active_session_id || null : null;
    if (typeof window !== 'undefined') {
      if (activeSessionId) {
        window.localStorage.setItem(storageKeys.activeSessionId, activeSessionId);
      } else {
        window.localStorage.removeItem(storageKeys.activeSessionId);
      }
    }
    return activeSessionId;
  } catch (error) {
    toast.error('Error loading active session: ' + getErrorMessage(error));
    return fallback;
  }
};

export const setActiveSessionId = async (sessionId) => {
  if (typeof window !== 'undefined') {
    if (sessionId) {
      window.localStorage.setItem(storageKeys.activeSessionId, sessionId);
    } else {
      window.localStorage.removeItem(storageKeys.activeSessionId);
    }
  }

  if (!isSupabaseConfigured()) return sessionId;

  try {
    const { error } = await supabase
      .from('active_sessions')
      .upsert(
        {
          user_key: 'default',
          active_session_id: sessionId || null,
          updated_at: new Date().toISOString()
        },
        { onConflict: 'user_key' }
      );

    if (error) throw error;

    return sessionId;
  } catch (error) {
    toast.error('Error saving active session: ' + getErrorMessage(error));
    return sessionId;
  }
};

export const deleteSessionById = async (sessionId) => {
  const fallbackSessions = readStorage(storageKeys.sessions, []);
  const fallbackNextSessions = fallbackSessions.filter((session) => session.id !== sessionId);

  if (!isSupabaseConfigured()) {
    writeStorage(storageKeys.sessions, fallbackNextSessions);
    const activeId = typeof window === 'undefined' ? null : window.localStorage.getItem(storageKeys.activeSessionId);
    if (activeId === sessionId) await setActiveSessionId(fallbackNextSessions[0]?.id || null);
    return fallbackNextSessions;
  }

  try {
    const { error } = await supabase
      .from('sessions')
      .delete()
      .eq('session_id', sessionId);

    if (error) throw error;

    const nextSessions = await getSessions();
    const activeId = await getActiveSessionId();

    if (activeId === sessionId) {
      await setActiveSessionId(nextSessions[0]?.id || null);
    }

    writeStorage(storageKeys.sessions, nextSessions);
    toast.success('Data saved successfully!');
    return nextSessions;
  } catch (error) {
    toast.error('Error deleting session: ' + getErrorMessage(error));
    writeStorage(storageKeys.sessions, fallbackNextSessions);
    return fallbackNextSessions;
  }
};

export const getPreferences = async () => {
  const fallback = readStorage(storageKeys.preferences, defaultPreferences);

  if (!isSupabaseConfigured()) return fallback;

  try {
    const { data, error } = await supabase
      .from('app_preferences')
      .select('preference_data')
      .eq('preference_key', 'default')
      .limit(1);

    if (error) throw error;

    const row = Array.isArray(data) ? data[0] : null;
    const preferences = row?.preference_data ? { ...defaultPreferences, ...toCamelCase(row.preference_data) } : fallback;
    writeStorage(storageKeys.preferences, preferences);
    return preferences;
  } catch (error) {
    toast.error('Error loading preferences: ' + getErrorMessage(error));
    return fallback;
  }
};

export const setPreferences = async (preferences) => {
  const existing = await getPreferences();
  const nextPreferences = { ...existing, ...(preferences || {}) };
  writeStorage(storageKeys.preferences, nextPreferences);

  if (!isSupabaseConfigured()) return nextPreferences;

  try {
    const { error } = await supabase
      .from('app_preferences')
      .upsert(
        {
          preference_key: 'default',
          preference_data: toSnakeCase(nextPreferences),
          updated_at: new Date().toISOString()
        },
        { onConflict: 'preference_key' }
      );

    if (error) throw error;

    return nextPreferences;
  } catch (error) {
    toast.error('Error saving preferences: ' + getErrorMessage(error));
    writeStorage(storageKeys.preferences, nextPreferences);
    return nextPreferences;
  }
};

export const useSupabase = () => {
  return useMemo(
    () => ({
      getSessions,
      saveSessions,
      getActiveSessionId,
      setActiveSessionId,
      deleteSessionById,
      getPreferences,
      setPreferences
    }),
    []
  );
};
